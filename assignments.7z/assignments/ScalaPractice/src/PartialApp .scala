
import java.util.Date

object PartialApp {
	def main(args: Array[String]){
		val date = new Date
		val logWithDateBound = log(date, _:String)
		logWithDateBound("Msg1")
		Thread.sleep(1000)
		logWithDateBound("msg2")
		Thread.sleep(1000)
		logWithDateBound("msg3")
	}
	
	def log(date: Date, message: String) = {
		println(date + "---" + message)
	}
}