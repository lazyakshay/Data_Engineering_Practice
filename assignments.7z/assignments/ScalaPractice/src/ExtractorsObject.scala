

object ExtractorsObject extends App {
  
  
  
  
  
  def apply(user:String, domain:String) = {
    user + "@" + domain
  }
  
//  def unapply(str:String): Option[(String, String)] = {
//    
//  }
}