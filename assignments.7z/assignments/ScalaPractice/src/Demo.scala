
object Demo {
	def main(args: Array[String]){
		println(factorial(0))
		println(factorial(1))
		println(factorial(5))
	}

	def factorial(x: Int): Int = {
		def fact(x: Int, acc: Int): Int = {
			if(x <=1)
				acc
			else
				fact(x-1, x*acc)
		}
		fact(x,1)
	}
}