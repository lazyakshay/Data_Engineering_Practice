
trait MachineA {
  def printA()
}

trait Print {
  def print()
}

abstract class PrintA4 {
  def printA4()
}

class A6 extends PrintA4 with Print{
  def printA() {
    println("Printing on Machine A")
  }
  
  def print() {
    println("print sheet")
  }
  
  def printA4() {
    println("Print A4 sheet")
  }
  
}

object TraitAbstractExa extends App{
   var obj = new A6() with MachineA
   obj.printA()
   obj.print()
   obj.printA4()
}