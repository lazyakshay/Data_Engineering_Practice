

case class Player(name: String, position: String)


//val heat = List(
//    Player("Mario Chamlers", "PG"),
//    Player("Dwayne Wade", "SG"),
//    Player("LeBronJame", "SF"),
//    Player("UdonisHaslem", "PF"),
//    Player("Chris Bosh", "C")
//    )

object Comprehensions {
  
}