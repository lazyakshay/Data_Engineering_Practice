package scalaclass.functions

object ParameterizedFunctionExample {
  
  def main(args: Array[String]) {
  
    functionExample(10,20)      
    
}
  
   def functionExample(a:Int, b:Int) = {  
      var c = a+b  
      println(c) 
   }
}