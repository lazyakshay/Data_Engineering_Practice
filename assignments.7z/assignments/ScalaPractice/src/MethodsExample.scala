package scalaclass.functions

object MethodsExample {
   def name: String = System.getProperty("java.version")
   
   def main(args: Array[String]) {
      
    println(add(1, 2)) // 3
    
    println(addThenMultiply(1, 2)(3)) // 9
    
    //println(addThenMultiply(1, 2)) // 9

    def addThenMultiply(x: Int, y: Int)(multiplier: Int): Int = (x + y) * multiplier
    
    println("Hello, " + name + "!")
    
    println(getSquareString(5)) // 25
  }
  
  
   def add(x: Int, y: Int): Int = x + y
   def getSquareString(input: Double): String = {
     val square = input * input
     square.toString
    }

}
