package oops


object IdFactory {
 private var counter = 0
   def create(): Int = {
    counter += 1
    counter
  }
}


object ObjectExample extends App{
  
  val newId: Int = IdFactory.create()
  println(newId) // 1
  val newerId: Int = IdFactory.create()
  println(newerId) // 2

}