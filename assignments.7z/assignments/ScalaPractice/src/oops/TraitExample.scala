package scalaclass.oops


trait Greeter1 {
   def greet(name: String): Unit
 }

trait Greeter2 {
 def greet(name: String): Unit =
    println("Hello, " + name + "!")

}

//class DefaultGreeter1 extends Greeter1

class DefaultGreeter2 extends Greeter2

class CustomizableGreeter(prefix: String, postfix: String) extends Greeter2 {
  override def greet(name: String): Unit = {
   println(prefix + name + postfix)
  }
}

object TraitExample extends App{
  
    val greeter2 = new DefaultGreeter2()
    greeter2.greet("Scala developer") // Hello, Scala developer!
    
    
     val customGreeter = new CustomizableGreeter("How are you, ", "?")
     customGreeter.greet("Scala developer") // How are you, Scala developer?

}