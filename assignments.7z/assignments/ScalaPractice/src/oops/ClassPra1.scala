//package oops
//
//import beans._
//
//class SPerson(name: String) {
//
//	val jp = new JPerson("Java Style")
//	//val sp = new SPerson("Scala Style")
//
//	println(jp.name)
//	//println(sp.name)
//
//	jp.name += "sucks"
//	sp.name += "rocks"
//
//	println(jp.getName)
//	println(sp.getName)
//}
//
//class JPerson() {
//	var _name: String = null
//	def this(_name: String) = {
//		this()
//		this._name = _name
//	}
//
//	//scala style
//	def name_ = (_name:String) => {
//	  this._name = _name
//	}
//	def name = this._name
//
//	//java style
//	def getName() = name
//	def setName(name:String) = this.name = name
//}
//
//
//object ClassPra1 {
//  
//}