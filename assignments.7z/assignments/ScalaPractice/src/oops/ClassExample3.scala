package oops

//Simple class that does nothing   
class Person(fname:String, lname:String)  

//A class with a method  
class Person2(fname:String, lname:String){  
  def greet = s"Hi $fname $lname!"  
}  

//A class with a public read only variable   
class Person3(fname:String, lname:String){  
  // a public read only field   
  val fullName = s"$fname $lname"   
  def greet = s"Hi $fullName!"  
}  


import beans._  
class SPerson(@BeanProperty var name:String)  


//auto creates a getter for fname, and getter + setter to lname  
class Person4(val fname:String, var lname:String)  


object ClassExample3 {

  def main(args: Array[String]) {
  
    val p1 = new Person("Alice", "In Chains")  
    //p1.fname / lname is not accessible  
   
    val p2 = new Person2("Bob", "Marley")  
    println(p2.greet)  
    //p2.fname / lname is not accessible  

    val p3 = new Person3("Carlos", "Santana")  
    println(p3.greet)  
    println(p3.fullName)   
    //p3.fname / lname is not accessible  

  val p4 = new Person4("Dave", "Matthews") {  
      //override the default string representation   
        override def toString = s"$fname $lname"   
  }  
  println(p4.fname)  
  println(p4.lname)  
  //lname is defined as var, so it has a setter too  
  p4.lname = "Grohl"  
  println(p4)
  
  var  s1=new SPerson("Dave");
  
  s1.setName("pawan")
  var nm=s1.getName()
  
  
  
  }
  }