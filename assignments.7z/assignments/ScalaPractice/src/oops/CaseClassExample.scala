package oops

object CaseClassExample {

  def main(args: Array[String]) {
        
      val cpointa = new CPointVal(1, 2)
      //cpointa.x=10;
      
      val cpointb = new CPointVar(1, 2)
      cpointb.x=10;
      
      //val cpointb = CPoint(1, 2)
      
      
      val ccpoint = CCPoint(1, 2)
      //ccpoint.x=10;
      val ccanotherPoint = CCPoint(1, 2)
      val ccyetAnotherPoint = CCPoint(2, 2)
      val cclastpoint = new CCPoint(1, 2)
      
      
      println(cpointa + " " + cpointb )
      println(ccpoint + " " + ccanotherPoint + " "+ ccyetAnotherPoint+ " "+ cclastpoint)

     }
 }
   
case class CCPoint(x: Int, y: Int)   // Immutable
class CPointVal(val x: Int, val y: Int)
class CPointVar(var x: Int, var y: Int)
