package oops

class OverloadClass {
 
  def add(num1:Int, num2:Int){
    println(num1+num2)
  }
  
  def add(num1:Int, num2:Int, num3:Int){
    println(num1+num2+num3)
  }
  
  def add(num1:Double, num2:Double){
    println(num1+num2)
  }
}

object OverloadExa {
  def main(args: Array[String]){
    var obj = new OverloadClass()
    obj.add(10,20)
    obj.add(10,20,20)
    obj.add(2.5,2.5)
    obj.add(2,4.5)
  }
}