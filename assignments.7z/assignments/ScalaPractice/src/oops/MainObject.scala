package oops

object MainObject {
  def main(args: Array[String]) {
    println("Akshay")
		//var stu = new Student(101, "Akshay");
		//stu.show()
	}
}