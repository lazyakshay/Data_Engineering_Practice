package oops

class A {
  val num1 = 10
  private val num2 = 20
  protected val num3 = 30
}

class B extends A {
  
  def show() {
    println(num1)
    //println(num2)
    println(num3)
  }
}

object Inheritance {
  def main(args: Array[String]){
    var obj = new B()
    obj.show()
    
    println("In main")
    println(obj.num1)
  //  println(obj.num2)
   // println(obj.num3)
  }
}