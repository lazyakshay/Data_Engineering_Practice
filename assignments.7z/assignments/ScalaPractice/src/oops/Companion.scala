package oops

class Main {
  def sayHello() {
    println("hello world")
  }
}

object Main {
  def sayHi(){
    println("Hi World")
  }
}

object Companion {
  def main(args: Array[String]){
    var aMain = new Main()
    aMain.sayHello()
    Main.sayHi()
  }
}