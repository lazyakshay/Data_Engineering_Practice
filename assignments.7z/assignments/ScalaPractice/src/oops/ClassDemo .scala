package oops

class Student(id:Int, name:String) {
	def show(){
		println("id: "+ id + " name: " + name) 
	}
}



object ClassDemo {
	def main(args: Array[String]) {
		var stu = new Student(101, "Akshay");
		stu.show()
	}
}