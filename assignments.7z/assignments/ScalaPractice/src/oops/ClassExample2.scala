package scalaclass.oops

class Student1{  
    var id:Int = 0;                         // All fields must be initialized  
    var name:String = null;  
}  

class Student2(id:Int, name:String){     // Primary constructor  
    def show(){  
        println(id+" "+name)  
    }  
}  

class Student3(id:Int, name:String){  
    def getRecord(){  
        println(id+" "+name);  
    }  
}  

class Arithmetic{  
    def add(a:Int, b:Int){  
        var add = a+b;  
        println("sum = "+add);  
    }  
}  


class MyClass {
    var myField : Int = 0;
        def this(value: Int) = {
          this();
          this.myField = value;
        }
 }


object ClassExample2 {

  def main(args: Array[String]) {
  
    var s1 = new Student1()               // Creating an object  
    println(s1.id+" "+s1.name);  


    var s2 = new Student2(100,"Martin")   
     // Passing values to constructor  
    s2.show()                // Calling a function by using an object  

     var student3a = new Student3(101,"Raju");  
     var student3b = new Student3(102,"Martin");  
     student3a.getRecord();  
     student3b.getRecord();  


      new Arithmetic().add(10,10); 
      

  }
  }