

object VariableDeclarationExample extends App{
     
      var myVar :Int = 10;
      val myVal :String = "With datatype";
      var myVar1 = 20;
      val myVal1 = "Without datatype ";
      
      
      println(myVar); 
      println(myVal);     
      println(myVar1); 
      println(myVal1);

      
      var myVara : String = "Foo"
      val myValb : String = "Foo"
      //var myVarc :Int;
      //val myVald :String;
      var myVare = 10;
      val myValf = "Hello, Scala!";
      val (myVar1g: Int, myVar2h: String) = Pair(40, "Foo")
      val (myVar1i, myVar2j) = Pair(40, "Foo")
  
      println(myVar1g);
      println(myVar2j);
      
      val list: List[Any] = List(
         "a string", 
         732, // an integer
         'c', // a character
         true, // a boolean value
         () => "an anonymous function returning a string"
      )
      
      list.foreach(element => println(element))


      
val x: Long = 987654321
val y: Float = x // 9.8765434E8 (note that some precision is lost in this case)
val face: Char = '�';
val number: Int = face // 9786
println(x);
println(y);
println(face);
println(number);
      
//Casting is unidirectional. This will not compile:
val x1: Long = 987654321
val y1: Float = x1 // 9.8765434E8
//val z1: Long = y1 // Does not conform


}