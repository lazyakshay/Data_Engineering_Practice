

object CurryingExa extends App {
  val str1 = "Hello, "
  val str2 = "Akshay"
  println("st1 + str2 = " + strcat(str1)(str2))
  
  
  def strcat(s1: String)(s2: String) = {
    s1+s2
  }
}