

object CurryingExa3 extends App {
  
  def filter(xs:List[Int], p:Int): List[Int] = {
    val res = xs.filterNot(item => (item%p != 0))
    res
  }
 
  
  val nums = List(1,2,3,4,5,6,7,8)
  println(filter(nums, 2))
  println(filter(nums, 3))
}