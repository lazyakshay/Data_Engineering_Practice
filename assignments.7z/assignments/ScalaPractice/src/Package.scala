

package orders {
  class Foo {
    override def toString = "Im in order.Foo"
  }
}


package customer {
  class Foo {
    override def toString = "I am in customer.Foo"
  }
}

package database {
  class Foo {
    def print() {
      println("Hello database package")
    }
  }
}

object Package extends App {
  println(new orders.Foo)
  println(new customer.Foo)
  new database.Foo().print()
}