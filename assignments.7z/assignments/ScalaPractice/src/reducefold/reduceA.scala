package scalaclass

object reduce 
{ 
    // Main method 
    def main(arg:Array[String]) 
    { 
        // initialize a sequence of elements 
        val seq_elements: Seq[Double] = Seq(3.5, 5.0, 1.5) 
        println(s"Elements = $seq_elements")  
  
        // find the sum of the elements 
        // using reduce function 
        val sum: Double = seq_elements.reduce((a, b) => a + b) 
        println(s"Sum of elements = $sum") 
    }    
} 