package scalaclass
// Scala program sum of elements  
// using scan function  
 
object scanA 
{ 
    // Main method 
    def main(arg:Array[String]) 
    { 
        //initialize a sequence of numbers 
        val numbers: Seq[Int] = Seq(4, 2, 1, 6, 9) 
        println(s"Elements of numbers = $numbers") 
  
        //find the sum of the elements using scan function 
        val iterations: Seq[Int] = numbers.scan(0)(_ + _) 
        println("Running total of all elements" + 
                s"in the collection = $iterations") 
    } 
}     