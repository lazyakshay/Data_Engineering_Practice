package scalaclass


object scanB 
{ 
    // Main method 
    def main(arg:Array[String]) 
    { 
        // initialize a sequence of strings 
        val str_elements : Seq[String] = Seq("hello",  
                            "Geeks", "For", "Geeks") 
        println(s"Elements = $str_elements") 
  
        // Concatenate strings with scan function 
        val concat : Seq[String] 
                    = str_elements.scan("")((a, b) => a + "-" + b) 
        println(s"After concatenation = $concat") 
    } 
}     