package scalaclass
// Scala program to find maximum and minimum  
// using reduce function  
object reduce1 
{ 
    // Main method 
    def main(arg:Array[String]) 
    { 
        // initialize a sequence of elements 
        val seq_elements : Seq[Double] = Seq(3.5, 5.0, 1.5) 
        println(s"Elements = $seq_elements") 
  
        // find the maximum element using reduce function 
        val maximum : Double = seq_elements.reduce(_ max _) 
        println(s"Maximum element = $maximum") 
  
        // find the minimum element using reduce function 
        val minimum : Double = seq_elements.reduce(_ min _) 
        println(s"Minimum element = $minimum") 
    } 
} 