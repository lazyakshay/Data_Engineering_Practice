package scalaclass
// Scala program sum of elements  
// using fold function  
  
// Creating object 
object foldA 
{ 
    // Main method 
    def main(arg:Array[String]) 
    { 
        // initialize a sequence of elements 
        val seq_elements: Seq[Double] = Seq(3.5, 5.0, 1.5) 
        println(s"Elements = $seq_elements")  
  
        // find the sum of the elements using fold function 
        val sum: Double = seq_elements.fold(0.0)((a, b) => a + b) 
        println(s"Sum of elements = $sum") 
    } 
} 