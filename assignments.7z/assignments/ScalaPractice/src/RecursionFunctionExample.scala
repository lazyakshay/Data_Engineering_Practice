package scalaclass.functions

object RecursionFunctionExample {
   def main(args: Array[String]) {
  
    var result=functionExample(15,5)      
    println(result)
}
   
   def functionExample(a:Int, b:Int):Int = {  
        //println(a+" "+b)
        if(b == 0)          // Base condition  
         0  
        else  
         a+functionExample(a,b-1)  
    }  

}
