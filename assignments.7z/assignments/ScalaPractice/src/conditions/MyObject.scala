package conditions
import scala.io.StdIn._

object MyObject {
  
  def main(args: Array[String]){
    val name = readLine()
    val discount = dis(name)
    showMsg(name, discount)
  }
  
  
  def dis(name: String): Double = {
    name match {
    case "Akshay" => 50
    case "Shwetha" => 30
    case "Siddhant" => 10
    case _ => 5
    }
  }
  
  def showMsg(name : String, discount : Double) {
    println(s"${name} got ${discount}% discount")
  }
}