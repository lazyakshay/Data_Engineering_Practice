
class Vehicle {
  val speed = 50
  def run() {
    println("vehicle is running with: " + speed)
  }
}

class Bike extends Vehicle {
  override val speed = 100
  override def run() {
    //super.run()
    println("Bike is running with: " + speed)
  }
}

object OverridingExa extends App {
  var b = new Bike()
  b.run()
}