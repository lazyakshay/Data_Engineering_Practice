

object FunctionExample2 {
  
   def main(args: Array[String]) {
      
       functionExample1()   
       var result = functionExample2()       // Calling function  
       println(result)  
       
       functionExample3()          // Calling function  
       println(functionExample3())
       println(square(10,20))
       
       def addOne(x:Int) = {
         x*2
         x+2
       }
       
       println(addOne(1))

   }
      def functionExample1()  {        // Defining a function  
          println("This is a simple function")  
    }  
      
    def functionExample2() = {       // Defining a function  
      var a = 10  
      a  
    }  

    def functionExample3()  = {       // Defining a function  
      var a = 10 
      a
    }  
    
    def square(num1:Int, num2:Int) = {
      num1*num1 + num2*num2
    }


}