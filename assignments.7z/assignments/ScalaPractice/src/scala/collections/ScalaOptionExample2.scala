package scalaclass.collections

case class Emp(
  var id: Int,
  var Name: String,
  var marks: Float,
  var gender: Option[String])

case class Cust(
  var id: Int,
  var Name: String,
  var marks: Float,
  var gender: Option[String])
 
 
object ScalaOptionExample2 {

  def main(args: Array[String]) {
    
    val newcapitals = Map(1->Emp(1,"pawan",23,Some("Male")),2->Cust(2,"seema",24,Some("Female")))
      
      println("show(capitals.get( \"1\")) : " + show(newcapitals.get(1)))
      println("show(capitals.get( \"2\")) : " + show(newcapitals.get(2)))
      println("show(capitals.get( \"3\")) : " + show(newcapitals.get(3)))
      
      
  }
   def show(x: Option[Any]) = x match {
      case Some(x) => if (x.isInstanceOf[Emp])  1 else 2
      case None => "?"
   }
}