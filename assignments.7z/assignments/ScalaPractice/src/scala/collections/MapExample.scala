package scalaclass.collections

import scala.collection.mutable._

  object MapExample {
  
  def main(args: Array[String]) {
  
    //keys() / values()/ isEmpty()

      val colors1 = Map("red" -> "#FF0000", "azure" -> "#F0FFFF", "peru" -> "#CD853F")
      val nums1: Map[Int, Int] = Map()
      println( "Keys in colors : " + colors1.keys )
      println( "Values in colors : " + colors1.values )
      println( "Check if colors is empty : " + colors1.isEmpty )
      println( "Check if nums is empty : " + nums1.isEmpty )

    //Concatenating Maps

      val colors2 = Map("red" -> "#FF0000", "azure" -> "#F0FFFF", "peru" -> "#CD853F")
      val colors3 = Map("blue" -> "#0033FF", "yellow" -> "#FFFF00", "red" -> "#FF0000")
      // use two or more Maps with ++ as operator
      var colors4 = colors2 ++ colors3
      println( "colors2 ++ colors3 : " + colors4 )
      // use two maps with ++ as method
      colors4 = colors2.++(colors3)
      println( "colors2.++(colors3)) : " + colors4 )

      //Keys and Values
      
      val colors5 = Map("red" -> "#FF0000", "azure" -> "#F0FFFF","peru" -> "#CD853F")
      colors5.keys.foreach{ i =>  
                     print( "Key = " + i )
                     println(" Value = " + colors5(i) )
                   }

      //Check for a key 
      val colors6 = Map("red" -> "#FF0000", "azure" -> "#F0FFFF", "peru" -> "#CD853F")

      if( colors6 contains( "red" )) {
         println("Red key exists with value :"  + colors6("red"))
      } else {
           println("Red key does not exist")
      }
      
      if( colors6.contains( "maroon" )) {
         println("Maroon key exists with value :"  + colors6("maroon"))
      } else {
         println("Maroon key does not exist")
      }

  }
}