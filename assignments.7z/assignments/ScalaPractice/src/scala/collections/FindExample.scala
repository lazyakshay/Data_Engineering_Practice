package scalaclass.collections

object FindExample {
  
  def main(args: Array[String]) {
    
      val iterator = Iterator(3, 6, 9, 4, 2)
      //apply operation
      val result = iterator.find(x=>{x % 2 == 0})
      //print result
      println(result)  
      
      val a = List(3, 6, 9, 4, 2)
      val b = a.find(x=>{x % 3 == 0})
      println(b)  
      
      val x = Array(3, 6, 9, 4, 2)
      val y = x.find(x=>{x % 3 == 0})
      println(y)  
      
      val pointList=List(Point(1,2),Point(3,4),Point(5,6),Point(7,8))
      println(pointList)
      //val resulta = pointList.find(i=>i.x >= 5)
      val resulta = pointList.find(_.x == 5)
      println(resulta)    
      
  }
  
  case class Point(x: Int, y: Int) 
}