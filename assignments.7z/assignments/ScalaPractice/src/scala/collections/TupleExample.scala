package scalaclass.collections

import scala.collection.mutable._

object TupleExample {
  
  def main(args: Array[String]) {
  
    //Section 1
     //Iterate over the Tuple
      val t1 = (4,3,2,1)
      val t11 = new Tuple4(4,3,2,1)
      t1.productIterator.foreach{ i =>println("Value = " + i )}
  
      println(t1._1)
      println(t1._2)
      println(t1._3)
      println(t1._4)
     //println(t1._5)
      
     //Converting to String
     val t2 = new Tuple3(1, "hello", Console)
     println("Concatenated String: " + t2.toString() )

     //Swap the Elements
     val t3 = new Tuple2("Scala", "hello")
      println("Swapped Tuple: " + t3.swap )

     //Use Custom Names 
      def getUserInfo = ("Al", 42, 200.0)
      
      val(name, age, weight) = getUserInfo
      
      println(name);
      println(age);
      println(weight);
      println(getUserInfo._1);
      println(getUserInfo._2);
      println(getUserInfo._3);
      //suppose you want to ignore the age/weight:
      val(nameonly, _, _) = getUserInfo
      println(nameonly);
      
      println("section 2")
      //Section 2
      val zz=5->"pawan"->34->5600                  
      println(zz._1)                         
      println(zz._1._1)
      println(zz._1._1._1)  
      println(zz._1._1._2) 
      println(zz._1._2)
      println(zz._2) 
  }
}