package scala.collections

object FlattenExample {
   def main(args: Array[String]) {
     
    var list = List(List(1,2), List(3,4))
    println(list) 
    var result = list.flatten
    println(result)  
    
       
    val fooList = List(List(Foo("Pawan", 25, 'male),Foo("Amit", 43, 'male)),List(Foo("Zoya", 37, 'female)))
    println(fooList) 
    val results = fooList.flatten
    println(results)
    
  }
  case class Foo(val name: String, val age: Int, val sex: Symbol) 
}