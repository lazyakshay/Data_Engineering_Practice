package scalaclass.collections

object FoldRight {
  def main(args: Array[String]) {
      
    val list = List(1, 2, 3 ,4)
      //apply operation to get sum of all elements of the list
      var result = list.foldRight(0)(_ + _)
      println(result)
      result = list.foldRight(2)(_ + _)
      println(result)
      result = list.foldRight(10)(_ * _)
      println(result)
      
      val fooList = Foo("Pawan", 25, 'male) ::
              Foo("Amit", 43, 'male) ::
              Foo("Zoya", 37, 'female) ::
              Nil
    val stringList = fooList.foldRight(List[String]("a","b","c")) { (f,z) =>
      //val stringList = fooList.foldRight(List[String]()) { (f,z) =>
    //val stringList = fooList.foldLeft(List[String]()) { (z, f) =>
    val title = f.sex match {
            case 'male => "Mr."
            case 'female => "Ms."
            }
          z :+ s"$title ${f.name}, ${f.age}"
          //s alow to use variables in any string
    }
        println(fooList)
        println(stringList)
       
  }
  case class Foo(val name: String, val age: Int, val sex: Symbol) 
}