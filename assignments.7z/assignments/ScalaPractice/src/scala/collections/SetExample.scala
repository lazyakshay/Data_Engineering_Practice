package scala.collections

import scala.collection.mutable._

object SetExample {
  
  def main(args: Array[String]) {
    
    //Section1 : Creating Set
    val set1 = Set()                            // An empty set  
    val games = Set("Cricket","Football","Hocky","Golf")    // Creating a set with elements  
    println(set1)  
    println(games) 

    
    //Section2  : Basic Set Operations
    println(games.head)           // Returns first element present in the set  
    println(games.tail)        	 // Returns all elements except first element.  
    println(games.isEmpty) 

    //Section3 : Merge two sets
    val alphabet = Set("A","B","C","D","E")   
    val mergeSet = games ++ alphabet            // Merging two sets  
            
    println("Elements in games set: "+games.size)   // Return size of collection  
    println("Elements in alphabet set: "+alphabet.size)   
    println("Elements in mergeSet: "+mergeSet.size)  
    println(mergeSet)  

    
    
    //Section 4 : Adding and Removing Elements
    games += "Racing"        // Adding new element  
    println(games)  
    games += "Cricket"       // Adding new element, it does not allow duplicacy.  
    println(games)  
    games -= "Golf"          // Removing element  
    println(games)  
     
   //Section 5 : Iterating Elements of a Set

    for(game <- games){  
        println(game)  
    }  
    games.foreach(println(_))  
    games.foreach(println)
    
    games.foreach((element:String)=> fun(element))
    
     //Section 6 : Set Operations
     println("Golf exists in the set : "+games.contains("Golf"))  
     println("Racing exists in the set : "+games.contains("Racing"))  


      //Section 7 : Set Maths Operations
    
        var games1 = Set("Cricket","Football","Hocky","Golf","C")  
        var alphabet1 = Set("A","B","C","D","E","Golf")  
        var setIntersection1 = games1.intersect(alphabet1)  
        println("Intersection by using intersect method: "+setIntersection1)  
        println("Intersection by using & operator: "+(games1 & alphabet1))  
        var setUnion1 = games1.union(alphabet1)  
        println(setUnion1)  

   //Section 8 : Sorted Set Operations
        
       var numbers: SortedSet[Int] = SortedSet(5,8,1,2,9,6,4,7,2)  
       numbers.foreach(print)  
        numbers+=20
        numbers+=11
        println
        numbers.foreach(print)  
        println
   //Section 9: Concatenating
        
        val fruit1 = Set("apples", "oranges", "pears")
        val fruit2 = Set("mangoes", "banana")

          // use two or more sets with ++ as operator
        var fruit = fruit1 ++ fruit2
        println( "fruit1 ++ fruit2 : " + fruit )

        // use two sets with ++ as method
        fruit = fruit1.++(fruit2)
        println( "fruit1.++(fruit2) : " + fruit )
   
        //Section 10: Max and Min
        
         val num = Set(5,6,9,20,30,45)
         // find min and max of the elements
          println( "Min element in Set(5,6,9,20,30,45) : " + num.min )
          println( "Max element in Set(5,6,9,20,30,45) : " + num.max )


     


  }
    def fun(element:String){
           println(element)
    }
    
}