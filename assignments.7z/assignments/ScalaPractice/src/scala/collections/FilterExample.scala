package scala.collections

object FilterExample {
  def main(args: Array[String]) {
    
    val x = List.range(1, 10)
    println(x)
    
    val evens1 = x.map(x=>List(x-1,x,x+1))
    println(evens1)
    
    val evens2 = x.filter(_ % 2 == 0)
    println(evens2)
   
    val evens3 = evens1.filter(x=> {
            
          x(0) % 2 == 0
            
    })
    println(evens3)
   
    val xx = Set(1,2,3,4,5,6,7,8,9)
    println(xx)
    val evensxx1 = xx.map(x=>Set(x-1,x,x+2))
    println(evensxx1)
    
    val evensxx2 = xx.filter(_ % 2 == 0)
    println(evensxx2)
    
    //Set is not an ordered collection - you can't get element by index.
   
     
    
  }
}