package scalaclass.collections


object TransformationExample {
  def main(args: Array[String]) {
    
    //Using map() function
    val l=List(1,2,3,4,5)
    l.map(x=>x*2)
    l.map(x=>println(x))
    val m=l.map(x=>fun(x))
    println(m)
    val n=l.map(x=>f(x))
    println(n)
    
     def g(v:Int) = List(v-1, v, v+1)
     
    val gg=l.map(x => g(x))
    println(gg)
    val gh=l.flatMap(x => g(x))
    println(gh)
   
    val x= List(List(1,2),List(3,4),List(5,6),List(7,8))
    val y=x.map(_(0)*2)
    println("y="+y)
    val z=x.flatMap(f=>List(f(0),f(1)))
    println("z="+z)
    
    val fruits = Seq("apple", "banana", "orange")
    println(fruits.map(_.toUpperCase))
    println(fruits.flatMap(_.toUpperCase))
  
    //map and flatMap work on a simple list of strings that you want to convert to Int:
    val strings = Seq("1", "2", "foo", "3", "bar")
    println(strings.map(toInt))
    println(strings.flatMap(toInt))
    println(strings.flatMap(toInt).sum)
    
  }
  def fun(x:Int)= {
    (x*x)
  }
  def f(x: Int) = if (x > 2) Some(x) else None
 
  def toInt(s: String): Option[Int] = {
    try {
        Some(Integer.parseInt(s.trim))
    } catch {
        case e: Exception => None
    }
}
}