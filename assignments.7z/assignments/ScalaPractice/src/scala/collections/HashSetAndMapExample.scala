package scalaclass.collections

  object HashSetAndMapExample {
  
  def main(args: Array[String]) {
  
   //HashSet
    import scala.collection.mutable.HashSet 
    val jetSet = new HashSet[String] 
    jetSet += "Lear" 
    jetSet += ("Boeing", "Airbus") 
    
    println(jetSet.contains("Cessna")) 

    var hashset = HashSet(4,2,8,0,6,3,45)  
    hashset.foreach((element:Int) => println(element+" "))  
      
    //HashMap
    
    import scala.collection.mutable.HashMap 
    val treasureMap = new HashMap[Int, String] 
    treasureMap += (1 -> "Go to island.") 
    treasureMap += (2 -> "Find big X on ground.") 
    treasureMap += (3 -> "Dig.") 
    println(treasureMap(2)) 

    
      
    
  }
}