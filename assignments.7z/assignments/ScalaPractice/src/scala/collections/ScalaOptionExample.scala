package scalaclass.collections

case class Student(
  id: Int,
  Name: String,
  marks: Float,
  gender: Option[String])

  
object TestStudent {
  
  private val students = Map(1 -> Student(10, "John", 62.5f, Some("male")),
    2 -> Student(12, "Adam", 70.5f, Some("female")))
    
  def findById(id: Int): Option[Student] = students.get(id)
  
  def findAll = students.values
}
 
object ScalaOptionExample {

  def main(args: Array[String]) {
    
    //Section 1
      val capitals = Map("France" -> "Paris", "Japan" -> "Tokyo")
      
      println("capitals.get( \"France\" ) : " +  capitals.get( "France" ))
      println("capitals.get( \"India\" ) : " +  capitals.get( "India" ))
    
      //Section 2
      val st1 = TestStudent.findById(22)
      if (st1.isDefined) {
         println(st1.get.id)
         println(st1.get.Name)
         println(st1.get.marks)
    }
      
    val newcapitals = Map("France" -> "Paris", "Japan" -> "Tokyo",1->2)
      
      println("show(capitals.get( \"Japan\")) : " + show(newcapitals.get( "Japan")) )
      println("show(capitals.get( \"India\")) : " + show(newcapitals.get( "India")) )
      println("show(capitals.get( \"1\")) : " + newcapitals.get( 1) )
      println("show(capitals.get( \"1\")) : " + show(newcapitals.get( 1)) )
   
  }
   def show(x: Option[Any]) = x match {
      case Some(x) => x
      case None => "?"
   }
}