package scalaclass.collections

object ZipExample {
  def main(args: Array[String]) {
    
      val list = List(1, 2, 3 ,4)
      val list1 = List("A", "B", "C", "D","E")
      //apply operation to create a zip of list
      val list2 = list zip list1
      //print list
      println(list)  
      println(list1)  
      println(list2)  
      println("Unzip")
     val (x,y) = list2.unzip
      println(x)
      println(y)
     val women = List("Wilma", "Betty")
     val men = List("Fred", "Barney")
     val couples = women zip men
     println(women)  
     println(men)  
     println(couples)  
     
     println("Unzip")
     val (a,b) = couples.unzip
      println(a)
      println(b)
      
     for ((wife, husband) <- couples) {
          println(s"$wife is married to $husband")
      }
      
      val products = Array("breadsticks", " pizza", " soft drink")
      val prices = Array(4)
      val productsWithPrice = products.zip(prices)
      println(products)  
      println(prices)  
      println(productsWithPrice)  
      println
      products.foreach(print)
      println
      prices.foreach(print)
      println
      productsWithPrice.foreach(print)
    
      
      
  }
  
}