package scala.collections

import scala.collection.mutable._

object ListExample {
  
  def main(args: Array[String]) {
    
    
    println("section1")
    //Section 1 : Basic Lists
    
    //List of Strings
    val fruit: List[String] = List("apples", "oranges", "pears")
    
    println("Print 0th Elemtn"+fruit(0))
    // List of Integers
    val nums: List[Int] = List(4, 2, 1, 2)

    // Empty List.
    val empty: List[Nothing] = List()

    // Two dimensional list
    val dim: List[List[Int]] =
     List(
          List(1, 0, 0),
          List(0, 1, 0),
          List(0, 0, 1)
     )

     println(fruit)
     println(nums)
     println(empty)
     println(dim)
     
     // List of Strings
     val fruit1 = "apples" :: ( "oranges" :: ("pears" :: Nil))

    // List of Integers
    val nums1 = 1 :: (2 :: (3 :: (4 :: Nil)))

    // Empty List.
    val empty1 = Nil

    // Two dimensional list
    val dim1 = (1 :: (0 :: (0 :: Nil))) ::
               (0 :: (1 :: (0 :: Nil))) ::
               (0 :: (0 :: (1 :: Nil))) :: Nil
    
    val dim2 =  ( 1 :: 0 :: 0 :: Nil ) ::
                ( 0 :: 1 :: 0 :: Nil ) ::
                ( 0 :: 0 :: 1 :: Nil ) :: Nil
     println(fruit1)
     println(nums1)
     println(empty1)
     println(dim1)
     println(dim2)
     
       //Section 2 :  List  Operations
     
      val fruitx = "apples" :: ("oranges" :: ("pears" :: Nil))
      val numsx = Nil

      println( "Head of fruit : " + fruitx.head )
      println( "Tail of fruit : " + fruitx.tail )
      println( "Check if fruit is empty : " + fruitx.isEmpty )
      println( "Check if nums is empty : " + numsx.isEmpty )

      //Concatenating 
      val fruit1y = "apples" :: ("oranges" :: ("pears" :: Nil))
      val fruit2y = "mangoes" :: ("banana" :: Nil)

      // use two or more lists with ::: operator
      var fruity = fruit1y ::: fruit2y
      println( "fruit1 ::: fruit2 : " + fruity )
      
      // use two lists with Set.:::() method
      fruity = fruit1y.:::(fruit2y)
      println( "fruit1y.:::(fruit2y) : " + fruity )

      // pass two or more lists as arguments
      fruity = List.concat(fruit1y, fruit2y)
      println( "List.concat(fruit1y, fruit2y) : " + fruity  )

      // uniform list
      
      val fruitz = List.fill(3)("apples") // Repeats apples three times.
      println( "fruitz : " + fruitz  )

      val numz = List.fill(10)(2)         // Repeats 2, 10 times.
      println( "numz : " + numz  )

      //Tabulating List
      
      // Creates 5 elements using the given function.
      val squares = List.tabulate(6)(n => n * n)
      println( "squares : " + squares  )

      val squaresx = List.tabulate(6)(_ * 5)
      println( "squaresx : " + squaresx  )
      
      val mul = List.tabulate( 4,5 )( _ * _ )      
      println( "mul : " + mul  )

      val mulx = List.tabulate( 4,5 )( _ + _ )      
      println( "mulx : " + mulx  )
      
    
      
       
  }
}