package scala.collections

import scala.collection.mutable._

class ArrayExample{  
    var arr = Array(1,2,3,4,5)     
   
    // Creating single dimensional array  
    def show1(){  
        for(a<-arr)                       
           // Traversing array elements  
            println(a)  
        
         println("Third Element  = "+ arr(2))        
         // Accessing elements by using index  
    }  
    
     def show2(arr:Array[Int]){  
        for(a<-arr)                // Traversing array elements  
            println(a)  
        println("Third Element = "+ arr(2))        // Accessing elements by using index  
    }  


}  


object ArrayExample {
  
  def main(args: Array[String]) {

      var a1 = new ArrayExample()  
      a1.show1()  
      
      //Passing Array into Function

      var arr2 = Array(1,2,3,4,5,6)    // creating single dimensional array  
      var a2 = new ArrayExample()  
      a2.show2(arr2) 

      
      //Iterating By using Foreach Loop
      var arr3 = Array(1,2,3,4,5)      // Creating single dimensional array  
      arr3.foreach((element:Int)=>println(element))       // Iterating by using foreach loop

      
      //Declaring Arrays
      
      var z1:Array[String] = new Array[String](3)
      var z2 = new Array[String](3)
      z2(0) = "Zara"; z2(1) = "Nuha"; z2(4/2) = "Ayan"
      var z3 = Array("Zara", "Nuha", "Ayan")
      val greetStrings = new Array[String](3) 
      greetStrings(0) = "Hello" 
      greetStrings(1) = ", " 
      greetStrings(2) = "world!\n" 
      for (i <- 0 to 2) print(greetStrings(i))
      
      for(i <- 0 until greetStrings.length){
          println("i is: " + i);
          println("i'th element is: " + greetStrings(i));
      }
      
      //Multi-Dimensional Arrays

      import Array._
      var myMatrix = ofDim[Int](3,3)
      // build a matrix
      for (i <- 0 to 2) {
         for ( j <- 0 to 2) {
            myMatrix(i)(j) = j;
         }
      }
      
      // Print two dimensional array
      for (i <- 0 to 2) {
         for ( j <- 0 to 2) {
            print(" " + myMatrix(i)(j));
         }
         println();
      }

      
      //Array of Arrays
      var arra = Array(Array(1,2,3,4,5), Array(6,7,8,9,10))  
      for(i<- 0 to 1){               // Traversing elements using loop  
           for(j<- 0 to 4){  
                print(" "+arra(i)(j))  
            }  
            println()  
        }
      
      //Concatenate Arrays
      var myList1 = Array(1.9, 2.9, 3.4, 3.5)
      var myList2 = Array(8.9, 7.9, 0.4, 1.5)
      var myList3 =  concat( myList1, myList2)
      // Print all the array elements
      for ( x <- myList3 ) {
         println( x )
      }

      //Create Array with Range:
      
      import Array._
      var myList4 = range(10, 20, 2)
      var myList5 = range(10,20)
      // Print all the array elements
      for ( x <- myList4 ) {
         print( " " + x )
      }
     
      println()
      for ( x <- myList5 ) {
         print( " " + x )
      }

      
}

}