package scalaclass.collections

object DropExample {
  def main(args: Array[String]) {
    val list = List(1, 2, 7, 4, 5)
    println(list)
    val result = list.drop(3)
    println(result)
    
    val pointList=List(Point(1,2),Point(3,4),Point(5,6),Point(7,8))
    println(pointList)
    val pointy = pointList.drop(2)
    println(pointy)
    
    
  }
  case class Point(x: Int, y: Int) 
}