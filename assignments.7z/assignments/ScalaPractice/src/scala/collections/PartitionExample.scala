package scalaclass.collections

object PartitionExample {
  def main(args: Array[String]) {
    
    val x = List(15, 10, 5, 8, 20, 12)
    println(x)
    val y = x.groupBy(_ > 10)
    println(y)    
    val z = x.partition(_ > 10)
    println(z)    
    
    val pointList=List(Emp("pawan",21),Emp("ravi",44),Emp("shreya",26),Emp("Raj",18))
    println(pointList)
    val pointy = pointList.groupBy(x=>fun(x))
    println(pointy)    
    val pointz = pointList.partition(x => fun(x))
    println(pointz)    
    
  }
  
  def fun(x:Emp)={
    //
     x.age > 20
  }
  
  case class Emp(name: String, age: Int)  
}