package scalaclass.exceptions
class ExceptionExample4{  
    @throws(classOf[NumberFormatException])  
    def validate()={  
        "abc".toInt  
    }  
}  
  
object ScalaThrow{  
    def main(args:Array[String]){  
        var e = new ExceptionExample4()  
        try{  
            e.validate()  
        }catch{  
            case ex : NumberFormatException => println("Exception handeled here"+ex)  
        }  
        println("Rest of the code executing...")  
    }  
}  

