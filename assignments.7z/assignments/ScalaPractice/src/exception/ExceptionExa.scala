package exception

//Akshay
class Employee1 {
  var name: String = ""
  var age:Int = 0
  var salary:Double = 0
  
  def setname(name:String) {
    this.name = name
  }
  
  def setage(age:Int) {
    if(age<18 || age >60) {
      throw new Exception("Invalid age")
    } else {
      this.age = age
    }
  }
  
  def setsalary(salary:Double) {
    this.salary = salary
  }
  
}

object ExceptionExa extends App {
  var emp = new Employee1()
  emp.setname("Akshay")
  emp.setage(50)
  emp.setsalary(50000)
  
  println(s"${emp.name}, ${emp.age}, ${emp.salary}")
}