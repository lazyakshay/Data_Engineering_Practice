package exception

class InvalidAgeException(s:String) extends Exception(s){}

class Employee2(name:String, age:Int, salary:Double) {
  @throws(classOf[InvalidAgeException])  
    def validateAge(age:Int){  
        if(age<18){  
            throw new InvalidAgeException("Not valid age")  
        }else{  
            println("Valid age")  
        }  
    }
}

object ExceptionExa2 extends App {
  val emp = new Employee2("Akshay",15,50000);
}