package scalaclass.exceptions

class InvalidAgeException(s:String) extends Exception(s){}  
class InvalidSalaryException(s:String) extends Exception(s){}  

class CustExceptionExample{  
    @throws(classOf[InvalidAgeException])  
    def validateAge(age:Int){  
        if(age<18){  
            throw new InvalidAgeException("Not eligible")  
        }else{  
            println("You are eligible")  
        }  
    }
    
    def validateSalary(sal:Int){  
        if(sal<15000){  
            throw new InvalidSalaryException("Wrong Salary")  
        }else{  
            println("You have good salary")  
        }  
    }  
}  
 object CustomExceptionExample{  
    def main(args:Array[String]){  
        var e = new CustExceptionExample()  
        try{  
            e.validateAge(35)
            e.validateSalary(88872)
            println("Lets get you onboarded")
        }catch{  
            case e : InvalidAgeException => println("You should be above 18 : "+e)
            case e : InvalidSalaryException => println("You need increase in your salary : "+e)
            case e : Exception => println("Some Exception : "+e)  
        }  
        
        
        
    }  
}  

