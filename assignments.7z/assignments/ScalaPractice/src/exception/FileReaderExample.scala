package scalaclass.exceptions
import java.io.FileReader
import java.io.FileNotFoundException
import java.io.IOException

object FileReaderExample {
   def main(args: Array[String]) {
      try {
         //val f = new FileReader("input.txt")
         val f = new FileReader("c:/tmp/data/Order33.csv")
         val a=f.read().toChar
         print(a)
         
      } catch {
         case ex: FileNotFoundException =>{
            println("Missing file c:/tmp/data/Order33.csv : exception")
         }
         
         case ex: IOException => {
            println("IO Exception")
         }
      } finally {
         println("Exiting finally...")
      }

   }
}
