package scalaclass.exceptions

class ExceptionExample{  
    def divide(a:Int, b:Int) = {  
            a/b             // Exception occurred here  
        println("Rest of the code is executing...")  
    }  
}  

class ExceptionExampleNew{  
    def divide(a:Int, b:Int) = {  
           try{  
            a/b  
            //
            //
            //
            //
            
        }catch{  
            case e: ArithmeticException => println("do not divide an value by 0")  
            case ex: Throwable =>println("found a unknown exception"+ ex)  
  
        }       
       
       println("Rest of the code is executing...")
    }  
}  

object ExceptionsExample {
   def main(args:Array[String]){  
        
        var e1 = new ExceptionExample()  
        e1.divide(100,2)  
   
        var e2=new ExceptionExampleNew()
        e2.divide(100,0)
    }  



}