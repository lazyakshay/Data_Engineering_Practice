package scalaclass.functions

object HigherOrderFunctionsExample2 {
  
  def main(args: Array[String]) = {  
    
     var result = double(sqr(10))      // Function composition  
     println(result)  
    }  
    def sqr(a:Int):Int = {  
        a*a
    }  
      
    def double(a:Int):Int = {  
        a*2  
    }  
}  
