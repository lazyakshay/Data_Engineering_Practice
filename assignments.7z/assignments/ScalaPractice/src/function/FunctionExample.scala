package scalaclass.functions

object FunctionExample {
   def main(args: Array[String]) {
      
          
     val addOne = (x: Int) => x + 1
      println(addOne(1)) // 2
    
     val add = (x: Int, y: Int) => x + y
     println(add(1, 2)) // 3

     val getTheAnswer = () => 42
     println(getTheAnswer()) // 42

     println((x: Int) => x + 1) // 2

     
   }
}