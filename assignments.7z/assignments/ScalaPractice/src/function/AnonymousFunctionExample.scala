package function

object AnonymousFunctionExample {
  def main(args: Array[String]) {

    
    var result1 = (a:Int, b:Int) => a+b       
        // Anonymous function by using => (rocket)  
     var result2 = (_:Int)+(_:Int)             
        // Anonymous function by 
        // using _ (underscore) wild card  
     println(result1(10,10))  
     println(result2(10,10))  
     
     var inc = (x:Int) => x+1
     var x = inc(7)-1
     println(x)
     var mul = (x: Int, y: Int) => x*y
     println(mul(3, 4))
     
    
    }  
}  
