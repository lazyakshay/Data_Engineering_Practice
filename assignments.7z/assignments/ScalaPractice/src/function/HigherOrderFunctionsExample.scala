package scalaclass.functions

object HigherOrderFunctionsExample {
  def main(args: Array[String]) = {  
    
    //Section1
     functionExample(25, sqr)
     functionExample(25, double)
     functionExample(25, sqrt)              	  
  
      def myfunction(xxxx:(String, String)=> String) = 
      { 
           xxxx("Dog", "Cat") 
      } 
          
      // Explicit type declaration of anonymous 
      // function in another function 
      val f1 = myfunction((str1: String,str2: String) => str1 + str2) 
      // Shorthand declaration using wildcard 
      val f2 = myfunction(_ + _) 
      println(f1) 
      println(f2) 

        
  }  
  
    def functionExample(a:Int, f:Int=>AnyVal):Unit = {  
      //logic on a
        println(f(a))                                   
		// Calling that function   
    }  
    
    def double(a:Int):Int = {  
        a*2
    } 
    def sqr(a:Int):Int = {  
        a*a  
    } 
    def sqrt(a:Int):Double = {  
        Math.sqrt(a) 
    } 
    
    
    
    }  
