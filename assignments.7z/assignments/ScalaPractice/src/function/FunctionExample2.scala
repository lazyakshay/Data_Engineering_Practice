package scalaclass.functions

object FunctionExample2 {
  
   def main(args: Array[String]) {
      
       functionExample1()   
       var result = functionExample2()       // Calling function  
       println(result)  
       
       functionExample3()          // Calling function  
       

   }
      def functionExample1()  {        // Defining a function  
          println("This is a simple function")  
    }  
      
    def functionExample2() = {       // Defining a function  
      var a = 10  
      a  
    }  

    def functionExample3() {       // Defining a function  
      var a = 10  
      a  
    }  


}