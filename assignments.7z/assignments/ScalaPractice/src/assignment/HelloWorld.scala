package assignment

object HelloWorld {
  def main(args: Array[String]) {
    println("Hello, World")
    val version = System.getProperty("Scala Version: " + util.Properties.versionString)
    println(version)
  }
}