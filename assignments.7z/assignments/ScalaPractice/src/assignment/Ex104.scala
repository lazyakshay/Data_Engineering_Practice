package assignment

object Ex104 {
  def main(args : Array[String]) {
    val num1 = 25
    val num2 = 5
    println((num1+num2 == 30) || (num1 ==30 || num2 == 30))
  }
}