package assignment

object SumofTwo {
  def main(args : Array[String]){
    println(add(10, 20))
  }
  
  def add(num1 : Int, num2 : Int): Int = {
    if(num1 == num2) 
      (num1+num2)*3
    else
      num1+num2
  }
}