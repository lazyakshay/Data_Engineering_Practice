package assignment

object Ex105 {
  def main(args: Array[String]) {
    println(check(115))
  }
  
  def check(n : Int) : Boolean = {
    Math.abs(100-n) <= 20 || Math.abs(300-n) <= 20
  }
}