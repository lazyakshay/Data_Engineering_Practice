package assignment

object AbsDiff {
  def main(args: Array[String]){
    val n = 53
    println(diff(n))
  }
  
  def diff(n : Int): Int = {
    if(n>51)
      (n-51)*3
    else
      51-n
  }
}