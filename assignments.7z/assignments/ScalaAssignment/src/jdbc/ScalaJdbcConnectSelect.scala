package jdbc

import java.sql.DriverManager
import java.sql.Connection

/**
 * A Scala JDBC connection example by Alvin Alexander,
 * https://alvinalexander.com
 */
object ScalaJdbcConnectSelect {

  def main(args: Array[String]) {
    // connect to the database named "mysql" on the localhost
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://localhost:3306/sys"
    val username = "root"
    val password = "root"
    
//    val driver = "org.postgresql.Driver"
//    val url = "jdbc:postgresql://server1.databricks.training:5432/training"
//    val username = "readonly"
//    val password = "readonly"

    // there's probably a better way to do this
    var connection:Connection = null

    try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)
      // create the statement, and run the select query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery("SELECT id, name, dept, salary FROM employee")
      //val resultSet = statement.executeQuery("SELECT * FROM people_1m limit 10")
      while ( resultSet.next() ) {
        val id = resultSet.getInt("id")
        val name = resultSet.getString("name")
        val dept = resultSet.getString("dept")
        val salary = resultSet.getDouble("salary")
        println(s"${id} ${name} ${dept} ${salary}")
      }
    } catch {
      case e => e.printStackTrace
    }
    connection.close()
  }

}