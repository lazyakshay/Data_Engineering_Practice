package collections

object Exa8 extends App {
  val list1 = List(99.5, 100.0, 50.0, 55.0, 70.0, 100.0, -1.0)
  val list2 = List(10.0, 20.0, 30.0, 40.0, 50.0)
  val combined = list1 ++ list2
  println(s"Combined number literals = ${combined}")
  println(s"Lowest number literal = ${combined.min}")
  println(s"Largest number literal = ${combined.max}")
}