package collections

object Exa9 extends App {
   val list = List(10, 77, 90, 50, 100, 110)
   var ch = false
   list.foreach(
       item => {
         if(item == 77) ch = true
       }
   )
   println(s"Does magic number 77 exist within the numerical value of ${list.mkString(",")}? ${ch.toString.toUpperCase()}")
}