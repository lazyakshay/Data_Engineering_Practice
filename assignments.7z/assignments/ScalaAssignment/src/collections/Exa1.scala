package collections
import scala.collection.immutable.TreeMap

object childSort extends Ordering[String] {
  def compare(key1:String, key2:String) = {
    key2.compareTo(key1)
  }
}

object Exa1 {
  def main(args: Array[String]) {
  val childAges = TreeMap(
      ("Bill", 9),
      ("Jonny", 8),
      ("Tommy", 11),
      ("Cindy", 13)
  )(childSort)
  
  println(s"Children to ages in reverse order by their names = ${childAges.mkString(", ")}")
  }
}