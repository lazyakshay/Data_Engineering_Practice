package collections

object Exa2 extends App{
  val basket1 = Set("Cake", "Milk", "Cheese", "Toilet Paper")
  val basket2 = Set("Water", "Milk", "Juice", "Cheese", "Bread")
  
  println("Common items are:")
  
  basket1.foreach(
    item => {
      if(basket2.contains(item)) println(item)
    } 
  )
}