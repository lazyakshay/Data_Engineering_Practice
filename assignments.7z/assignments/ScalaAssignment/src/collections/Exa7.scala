package collections

object Exa7 extends App {
  val num1 = Set(1, 3, 5, 10, 20)
  val num2 = Set(20, 17, 18, 99, 0)
  println(s"Number literals in set one bit not in set two = ${num1 -- num2}")
  println(s"Number literals in set two bit not in set one = ${num2 -- num1}")
}