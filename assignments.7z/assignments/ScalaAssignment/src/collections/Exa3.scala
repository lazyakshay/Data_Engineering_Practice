package collections
import scala.collection.mutable._

object Exa3 extends App{
  
  val basket = Seq("Milk", "Cheese", "Donuts", "Apples", "Bananas")
  
  val newBasket = basket.filterNot(ele => (ele == "Apples" || ele == "Bananas"))
  
  println(newBasket.mkString("<items values= \"", "|", "\"></items>"))
}