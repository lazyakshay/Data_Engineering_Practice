package collections

object Exa4 extends App{
  
  val shopping = List(
      ("T-Shirt", "Medium", "10.99"),
      ("Polo-Shirt", "Large", "4.99"),
      ("Vest", "Small", "5.99"),
      ("T-Shirt", "Small", "4.99"),
      ("T-Shirt", "Small", "4.99")
  )
  
  shopping.foreach {
      item => {
        if(item._1 == "T-Shirt") 
          println(s"${item._1.toUpperCase()} is priced at $$${item._3} for the ${item._2} size")
        else 
          println(s"${item._1} is priced at $$${item._3} for the ${item._2} size")
      }
  }
}