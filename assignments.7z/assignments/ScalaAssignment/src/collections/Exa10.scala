package collections

object Exa10 extends App {
  var list = List.range(300, 340)
  var oddlist = list.filterNot(item => item%2 == 0)
  println(s"Odd number between 300 and 340 = ${oddlist.mkString("||")}")
}