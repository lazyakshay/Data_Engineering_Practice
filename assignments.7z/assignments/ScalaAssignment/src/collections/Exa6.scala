package collections

object Exa6 extends App {
  val numbers = Vector(10, 20, 47, -2, 99, -98)
  println(s"The smallest item in the Vector = ${numbers.min}")
  println(s"The largest item in the Vector = ${numbers.max}")
}