package collections

object Exa5 extends App {
  val numbers = List.range(100, 150, 10)
  println(s"Elements of Vector from 100 to 150, excluding the 150 number literal = ${numbers.mkString(", ")}")
  println(s"Sum for elements in the List = ${numbers.sum}")
}