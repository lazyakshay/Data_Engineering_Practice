package assignment

//akshay

case class Employee(name:String, age:Int, salary:Double)

object EmployeeExa extends App {
  
  
  val emplist = List(("emp1", 25, 10000), ("emp2", 22, 20000), ("emp3", 24, 40000), ("emp4", 53, 30000))
  val temp = emplist.reduce((a,b) => (a._1+b._1, a._2+b._2, a._3+b._3))
  println("total salary:" + temp._3)
  println("avg age is: " + (temp._2/emplist.size).toDouble)
  
  
  
  val emps = List(
      Employee("emp1", 25, 10000),
      Employee("emp2", 22, 20000),
      Employee("emp3", 24, 40000),
      Employee("emp4", 53, 30000),
      Employee("emp5", 22, 150000),
      Employee("emp6", 23, 14000),
      Employee("emp7", 26, 11000),
      Employee("emp8", 34, 99000),
      Employee("emp9", 45, 1120000),
      Employee("emp10", 56, 140000)
  )
  
  totalSal(emps)
  avgAge(emps)
  
  def totalSal(emp : List[Employee]): Unit = {
    //val sal = emp.reduce((a,b) => a.copy(a.name, a.age, a.salary+b.salary))
    val totalSal : Double = emp.map(_.salary).reduce((a,b) => a+b)
    println("Total Salary is: " + totalSal)
   // println("total salary is: " + sal.salary)
  }
  
  
  def avgAge(emp: List[Employee]): Unit = {
    val totalage = emp.reduce((a,b) => a.copy(a.name, a.age+b.age, a.salary))
    val avgAge = (totalage.age/emp.size).toDouble
    println("average age is: " + avgAge)
  }
}