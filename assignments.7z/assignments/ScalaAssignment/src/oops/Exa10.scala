package oops

final case class Car(name:String, price:Double)


object Exa10 extends App {

 type CarStock = Tuple2[Car, Int]

 val vwPassatStock = new CarStock(Car("vw passat", 10000), 100)
 val vwGolfStock = new CarStock(Car("vw golf", 12000), 50)
 val bmw3Stock = new CarStock(Car("bmw 3 series", 20000), 200)
 val bmw5Stock = new CarStock(Car("bmw 5 series", 50000), 75)
 val mazdaStock = new CarStock(Car("mazda 3", 15000), 49)

 val carInventory = List(vwPassatStock, vwGolfStock, bmw3Stock, bmw5Stock, mazdaStock)
 
 println("Cars sorted by lowest stock: ")
 orderByLowestStock(carInventory)
 
 def orderByLowestStock(inventory: List[CarStock]): Unit = {
   inventory
     .sortBy(_._2)
     .foreach { case (car, stock) =>
       println(s"${car.name} stock = $stock")
     }
 } 
 
}