package oops

case class ShoppingCart(name: String, price: Double, qtyBought: Int)

object Exa01 extends App {
  val items = ("packet of rice", 10.99, 5)
  println(s"A ${items._1} is currently priced at $$${items._2}, and the customer bought ${items._3}.")
  
  val itemsClass = ShoppingCart(
      name = "packet of rice",
      price = 10.99,
      qtyBought = 5
  )
  println(s"A ${itemsClass.name} is currently priced at $$${itemsClass.price}, and the customer bought ${itemsClass.qtyBought}.")
}