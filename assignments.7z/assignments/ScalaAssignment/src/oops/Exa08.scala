package oops

abstract class Students(name: String, age:Int) {
  def printName() : Unit
}

class PrimaryStudent(name:String, age:Int) extends Students(name, age) {
  override def printName(): Unit = {
    println(s"name = ${name}, age = ${age}")
  }
}

class SecondaryStudent(name:String, age:Int) extends Students(name, age) {
  override def printName(): Unit = {
    println(s"name = ${name}, age = ${age}")
  }
}

object Exa08 extends App {
  
  val studentlist = List(
        new PrimaryStudent("John", 8),
        new PrimaryStudent("Jill", 10),
        new SecondaryStudent("James", 13),
        new SecondaryStudent("Joe", 14),
        new SecondaryStudent("Jack", 11)
  )
  listStudents(studentlist)
  
  def listStudents(students : List[Students]):Unit = {
    students.foreach(student => student.printName())
  }
}