package oops


case class ShoppingCarts(name: String, price: Double, qtyBought: Int)

object Exa02 {
  
  def main(args: Array[String]){
    
  var CartItems = List(
      new ShoppingCarts(
      name = "vanilla ice cream",
      price = 2.99,
      qtyBought = 10
      ), 
      new ShoppingCarts(
      name = "hocolate biscuits",
      price = 3.99,
      qtyBought = 3
      ),
      new ShoppingCarts(
      name = "cupcakes",
      price = 4.99,
      qtyBought = 5
      )
  )
  
  printCart(CartItems)
  printIceCream(CartItems)
  }
  
  
  def printCart(CartItems : List[ShoppingCarts]) {
    CartItems.foreach(item => 
      println(s"${item.qtyBought} ${item.name} at $$${item.price} each")  
    )
  }
  
  
  def printIceCream(CartItems : List[ShoppingCarts]){
    CartItems.foreach { {
     case ShoppingCarts("cupcakes", _, _) => println("Found a cupcake item.")
     case ShoppingCarts(_,_,_) => println("Found another item.")
     }
   }
  }
  
}
