package oops

class BasketValidator() {
  def validate[T](item : T) : Unit = {
    item match {
       case i: String =>
         println(s"Found a valid item = $i")
       case i: Double =>
         println(s"Item $i of type Double is not valid.")
       case i: Int =>
         println(s"Item $i of type Int is not valid.")
       case _ =>
         println(s"Item $item should be removed from the basket.")
       }
  }
}

object Exa04 extends App {
  val basket = List("Cupcake", 2.99, 100L, 7, "Ice Cream")
  basket.foreach(
      item => new BasketValidator().validate(item)    
  )
}