package oops

object Exa03 {
  
  def numberToString(num : Int) : String = {
    num.toString()
  }
  
  def numbersToString(num : Int*) : String = {
    num.mkString(" :: ")
  }
  
  def main(args: Array[String]){
    println("10 as String literal = " + numberToString(10))
    println(s"10, 11, 12 as String literals = ${numbersToString(10, 11, 12)}")
  }
}
