package oops

case class Student(name: String, age: Int)

object Exa07 extends App {
  
  val students = List(
      Student(name = "John", age = 7),
      Student(name = "Jack", age = 13),
      Student(name = "Joe", age = 15),
      Student(name = "Jill", age = 15),
      Student(name = "James", age = 11)
  )
  
  println(students.mkString("\n"))
  
  def checkAge(student: List[Student]) : Boolean = {
    var res = false
    student.foreach(
      items => {
        if(items.age == 15) {
          res = true
        }
      }
    )
    res
  }
  
  val check = checkAge(students)
  println(s"Is there a student who is 15 years old = ${check}")
}