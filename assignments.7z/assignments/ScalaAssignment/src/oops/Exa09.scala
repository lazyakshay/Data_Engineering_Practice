package oops

final case class Student9(name: String, age: Int, favoriteSnack: Option[String] = None)

object Exa09 extends App {
  
 val jack = Student9("Jack", 15, Some("cupcake"))
 val jill = Student9("Jill", 10, Some("ice cream"))
 val joe = Student9("Joe", 7, None)
 val james = Student9("James", 10, Some("chocolate"))
 val john = Student9("John", 11, None)
 

 val joeUpdated = joe.copy(favoriteSnack = Some("cupcake"))
 
  listStudents(List(jack, jill, joeUpdated, james, john))
  
  def listStudents(students: List[Student9]):Unit = {
    students.foreach{ student=>
     print(s"name = ${student.name} is ${student.age} years old. ")
     print(s"Favorite snack is ${student.favoriteSnack.getOrElse(" nothing!")}")
     println("\n")
   }
  }
}