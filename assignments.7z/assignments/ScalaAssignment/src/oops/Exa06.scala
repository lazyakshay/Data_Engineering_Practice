package oops

object Exa06 extends App {
  
  def toUpper(input : String) : String = {
    input.toUpperCase()
  }
  
  def toLower(input: String) : String = {
    input.toLowerCase()
  }
  
  def formatNames(name: String)(func: String => String): String = {
     func(name)
   }

   println(formatNames("Bob")(toUpper(_)))
   println(formatNames("Joe")(toLower(_)))
   println(formatNames("Jack")(toUpper(_)))
}