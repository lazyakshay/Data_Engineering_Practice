package pawan.sparkclass

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object CreateRDD {

  def main(args:Array[String]): Unit ={
   
    System.setProperty("hadoop.home.dir", "c:/tmp/");
   val conf = new SparkConf()
      .setAppName("CreateRDD")
      .setMaster("local")
    
  //create spark context object
  val sc = new SparkContext(conf)

    val rdd=sc.parallelize(Seq(("Java", 20000), ("Python", 100000), ("Scala", 3000)))
    rdd.foreach(println)

    val rdd1 = sc.textFile("/path/textFile.txt")

    val rdd2 = sc.wholeTextFiles("/path/textFile.txt")
    rdd2.foreach(record=>println("FileName : "+record._1+", FileContents :"+record._2))

    val rdd3 = rdd.map(row=>{(row._1,row._2+100)})
    rdd3.foreach(println)

  
  }
}
