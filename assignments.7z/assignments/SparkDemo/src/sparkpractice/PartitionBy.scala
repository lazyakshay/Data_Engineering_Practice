package pawan.sparkclass

import org.apache.spark.HashPartitioner
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf


object PartitionBy {


  def main(args:Array[String]): Unit = {

    System.setProperty("hadoop.home.dir", "c:/tmp/");
    //Create conf object
    
    val conf = new SparkConf()
      .setAppName("PartitionBy")
      .setMaster("local")
      //create spark context object
    
    val sc = new SparkContext(conf)

    val rdd = sc.textFile("C:/tmp/resources/zipcodes.csv")

    val rdd2:RDD[Array[String]] = rdd.map(m=>m.split(","))
    
    val rdd3 = rdd2.map(a=>(a(1),a.mkString(",")))
  
    val rdd4 = rdd3.partitionBy(new HashPartitioner(3))

    rdd4.saveAsTextFile("/tmp/data/out/out5")


  }
}
