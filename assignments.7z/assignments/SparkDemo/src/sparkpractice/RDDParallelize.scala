//2
package sparkpractice


import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD

object RDDParallelize {

  def main(args: Array[String]): Unit = {
       System.setProperty("hadoop.home.dir", "D:/hadoop/");

      val conf = new SparkConf()
      .setAppName("RDDParallelize")
      .setMaster("local")
    
      //create spark context object
      val sc = new SparkContext(conf)
      
      
      val rdd:RDD[Int] = sc.parallelize(List(1,2,3,4,5))
      //val rdd:RDD[Int] = sc.parallelize(Seq.empty[String])

      val rddCollect:Array[Int] = rdd.collect()
      println("Number of Partitions: "+ rdd.getNumPartitions)
      println("Action: First element: "+rdd.first())
      println("Action: RDD converted to Array[Int] : ")
      rddCollect.foreach(println)
  }
}