package sparkpractice

import org.apache.spark.sql.SparkSession

object SparkSessionTest {
  
  def main(args: Array[String]):Unit = {
    System.setProperty("hadoop.home.dir", "D:/hadoop/");
    val spark = SparkSession.builder()
    .master("local[1]")
    .appName("SparkByExample")
    .getOrCreate();
    
    println("First Spark Context: ")
    println("App Name: " + spark.sparkContext.appName);
    println("Deploye Mode: " + spark.sparkContext.deployMode);
    println("Master: " + spark.sparkContext.master);
    
    
    val sparkSession2 = SparkSession.builder()
    .master("local[1]")
    .appName("SparkByExample-test")
    .getOrCreate();
    
    println("Second Spark Context: ")
    println("App Name: " + sparkSession2.sparkContext.appName);
    println("Deploye Mode: " + sparkSession2.sparkContext.deployMode);
    println("Master: " + sparkSession2.sparkContext.master);
    
  }
  
}