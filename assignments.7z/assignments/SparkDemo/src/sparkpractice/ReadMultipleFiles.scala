//3
package pawan.sparkclass
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object ReadMultipleFiles extends App {

  System.setProperty("hadoop.home.dir", "c:/tmp/");
  
val conf = new SparkConf()
      .setAppName("ReadMultipleFiles")
      .setMaster("local")
    
  //create spark context object
  val sc = new SparkContext(conf)

  sc.setLogLevel("ERROR")

  println("read all text files from a directory to single RDD")
  val rdd = sc.textFile("C:/tmp/data/files/*")
  rdd.foreach(f=>{
    println(f)
  })

  println("read text files base on wildcard character")
  val rdd2 = sc.textFile("C:/tmp/data/files/text*.txt")
  rdd2.foreach(f=>{
    println(f)
  })

  println("read multiple text files into a RDD")
  val rdd3 = sc.textFile("C:/tmp/data/files/text01.txt,C:/tmp/data/files/text02.txt")
  rdd3.foreach(f=>{
    println(f)
  })

  println("Read files and directory together")
  val rdd4 = sc.textFile("C:/tmp/data/files/text01.txt,C:/tmp/data/files/text02.txt,C:/tmp/data/files/*")
  rdd4.foreach(f=>{
    println(f)
  })


  val rddWhole = sc.wholeTextFiles("C:/tmp/data/files/*")
  rddWhole.foreach(f=>{
    println(f._1+"=>"+f._2)
  })

  val rdd5 = sc.textFile("C:/tmp/data/files/*")
  val rdd6 = rdd5.map(f=>{
    f.split(",")
  })

  rdd6.foreach(f => {
    println("Col1:"+f(0)+",Col2:"+f(1))
  })

}

