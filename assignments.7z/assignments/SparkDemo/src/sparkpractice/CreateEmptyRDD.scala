package pawan.sparkclass


import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object CreateEmptyRDD extends App{

  System.setProperty("hadoop.home.dir", "c:/tmp/");
   
  val conf = new SparkConf()
      .setAppName("CreateEmptyRDD")
      .setMaster("local")
    
  //create spark context object
  val sc = new SparkContext(conf)
    
  val rdd = sc.emptyRDD
  val rddString = sc.emptyRDD[String]

  println(rdd)
  println(rddString)
  println("Num of Partitions: "+rdd.getNumPartitions)

  //rddString.saveAsTextFile("test.txt") // returns error

  val rdd2 = sc.parallelize(Seq.empty[String])
  println(rdd2)
  println("Num of Partitions: "+rdd2.getNumPartitions)

  //rdd2.saveAsTextFile("test3.txt")

  // Pair RDD

  type dataType = (String,Int)
  var pairRDD = sc.emptyRDD[dataType]
  println(pairRDD)

}
