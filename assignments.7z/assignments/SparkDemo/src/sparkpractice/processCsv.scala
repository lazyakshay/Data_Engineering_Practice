package pawan.sparkclass

import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object processCsv extends App{
 
  
   System.setProperty("hadoop.home.dir", "c:/tmp/");
   
   val conf = new SparkConf()
      .setAppName("processCsv")
      .setMaster("local")
    
    //create spark context object
    val sc = new SparkContext(conf)
 
    val rddFromFile = sc.textFile("C:/tmp/data/Order.csv")
    println(rddFromFile.getNumPartitions)
    val rddmap=rddFromFile.map(x => fun(x))
    rddmap.foreach(x=>println(x))
    val rddgrp=rddmap.groupBy(f=>f.split(",")(1))
    rddgrp.foreach(x=>println(x))
    
    
    def fun(x:String) = {
              
        var arr:Array[String]=x.split(",") 
         arr(3)=arr(3).toLowerCase()
         arr(0)+ "," +arr(1)+"," +arr(2)+"," +arr(3)
     }
}

