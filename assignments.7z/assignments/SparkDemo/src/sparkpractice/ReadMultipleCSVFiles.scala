//4
package sparkpractice

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD

object ReadMultipleCSVFiles extends App {

  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  
  val conf = new SparkConf()
      .setAppName("ReadMultipleCSVFiles")
      .setMaster("local")
    
      //create spark context object
      val sc = new SparkContext(conf)
 
  sc.setLogLevel("ERROR")

  println("spark read csv files from a directory into RDD")
  val rddFromFile = sc.textFile("D:/hadoop/data/datafilescsv/")
  println(rddFromFile.getClass)

  val rdd = rddFromFile.map(f=>{
    f.split(",")
  })

  println("Iterate RDD")
  rdd.foreach(f=>{
    println("Col1:"+f(0)+",Col2:"+f(1))
  })
  println(rdd)

  println("Get data Using collect")
  rdd.collect().foreach(f=>{
    println("Col1:"+f(0)+",Col2:"+f(1))
  })

  println("read all csv files from a directory to single RDD")
  val rdd2 = sc.textFile("D:/hadoop/data/datafilescsv/*")
  rdd2.foreach(f=>{
    println(f)
  })

  println("read csv files base on wildcard character")
  val rdd3 = sc.textFile("D:/hadoop/data/datafilescsv/text*.txt")
  rdd3.foreach(f=>{
    println(f)
  })

  println("read multiple csv files into a RDD")
  val rdd4 = sc.textFile("D:/hadoop/data/datafilescsv/text01.txt,D:/hadoop/data/datafilescsv/text02.txt")
  rdd4.foreach(f=>{
    println(f)
  })

}
