package pawan.sparkclass


import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD


object MatchesExample_1 extends App {

  System.setProperty("hadoop.home.dir", "c:/tmp/");
  val conf = new SparkConf()
      .setAppName("MatchesExample_1")
      .setMaster("local")
    
       //create spark context object
  val sc = new SparkContext(conf)

//import CSV files to RDD

val roleRDD = sc.textFile("/tmp/data/role.csv")
val matchRDD = sc.textFile("/tmp/data/match.csv")
val playerRDD = sc.textFile("/tmp/data/player.csv")
val groundRDD = sc.textFile("/tmp/data/ground.csv")

//1.Batsman/All rounder who scored more than 20 runs in all matches

// Filter out players having roles as Batsman or Allrounder
val roleRDDFilter = roleRDD.filter(rec => rec.split(",")(1) == "Batsman" || rec.split(",")(1) == "Allrounder")
roleRDDFilter.foreach(println)

//Creating tuple from matchRDD containing (PlayerNumber, Runs) and also filtering out players having Runs column as empty
val matchRDDMap = matchRDD.filter(rec => !(rec.split(",")(2)=="Runs"))
matchRDDMap.collect.foreach(println)
val matchRDDMap1 = matchRDDMap.filter(rec => !rec.split(",")(2).isEmpty).map(rec => (rec.split(",")(1), rec.split(",")(2).toInt))
matchRDDMap1.collect.foreach(println)

//Grouping By key of matchRDD and then selecting those List of scores which do not have any score less than 20
val matchGroupBy = matchRDDMap1.groupByKey().map(rec => (rec._1, rec._2.toList.filter(_ < 20).isEmpty)).filter(rec => rec._2 ==  true)
matchGroupBy.collect.foreach(println)

//Mapping roleRDD in the tuple (playerNumber, Role)
val roleRDDMap = roleRDDFilter.map(rec => (rec.split(",")(0), rec.split(",")(1)))
roleRDDMap.collect.foreach(println)

//Mapping playerRDD in the tuple (playerNumber, playerRole)
val playerRDDMap = playerRDD.map(rec => (rec.split(",")(0), rec.split(",")(1)))
playerRDDMap.collect.foreach(println)

//Join RDDs to find out the player name and player role
val roleJoinMatch = matchGroupBy.join(roleRDDMap).join(playerRDDMap)
roleJoinMatch.collect.foreach(println)

//mapping roleJoinMatch to filter out only player name and role
roleJoinMatch.map(rec => (rec._2._2, rec._2._1._2)).collect.foreach(println)

//(Rahane,Batsman)

for(i<-0 to 100000000){println(i)}

}

//Application->Job->Stage->Task
