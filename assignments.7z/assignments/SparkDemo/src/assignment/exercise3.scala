package assignment

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object exercise3 extends App {
  
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  
  val conf = new SparkConf()
  .setAppName("Akshay")
  .setMaster("local")
  
  val sc = new SparkContext(conf)
  
  val fileRDD = sc.wholeTextFiles("D:/hadoop/data/2010_Census_Populations_by_Zip_Code.csv")
  //fileRDD.foreach(println)
  
  val flatfileRDD = fileRDD.flatMap(line => line._2.split("\n"))
  //flatfileRDD.foreach(println)
  
  //val totalPop = flatfileRDD.map(line => )
  //totalPop.foreach(println)
  
  
}