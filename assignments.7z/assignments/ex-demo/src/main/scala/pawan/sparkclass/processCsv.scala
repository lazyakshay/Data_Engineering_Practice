package pawan.sparkclass

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object CsvToParquet extends App{
  
  
   System.setProperty("hadoop.home.dir", "c:/tmp/");
   val spark:SparkSession = SparkSession.builder()
    .master("local[1]")
    .appName("processCsv")
    .getOrCreate()
     val sc = spark.sparkContext
    val rddFromFile = sc.textFile("C:/tmp/data/Order.csv")
    println(rddFromFile.getNumPartitions)
    val rddmap=rddFromFile.map(x => fun(x))
    rddmap.foreach(x=>println(x))
    val rddgrp=rddmap.groupBy(f=>f.split(",")(1))
    rddgrp.foreach(x=>println(x))
    
    
    def fun(x:String) = {
              
        var arr:Array[String]=x.split(",") 
         arr(3)=arr(3).toLowerCase()
         arr(0)+ "," +arr(1)+"," +arr(2)+"," +arr(3)
     }
}

