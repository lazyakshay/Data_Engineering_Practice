//1
package pawan.sparkclass
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
object WordCount2 {
def main(args: Array[String]) {
System.setProperty("hadoop.home.dir", "c:/tmp/");
//Create conf object
val conf = new SparkConf()
.setAppName("WordCount")
.setMaster("local[4]")
//create spark context object
val sc = new SparkContext(conf)

//Read file and create RDD
val rawData = sc.textFile("/tmp/resources/*.csv")
//convert the lines into words using flatMap operation
val words = rawData.flatMap(line => line.split(" "))
//count the individual words using map and reduceByKey operation
val wordCount = words.map(word => (word, 1)).reduceByKey(_ + _)
//Save the result
wordCount.saveAsTextFile("/tmp/data/out/outx")
//stop the spark context
    
    for ( i <- 0 to 100000000)
      println(i)
sc.stop
}
}
