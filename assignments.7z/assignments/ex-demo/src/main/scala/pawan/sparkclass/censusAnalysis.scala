package pawan.sparkclass

import org.apache.hadoop.io.compress.GzipCodec
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.rdd.SequenceFileRDDFunctions

import scala.reflect.macros.whitebox

object censusAnalysis extends App {

  System.setProperty("hadoop.home.dir", "c:/tmp/");
  

  val spark = SparkSession
    .builder()
    .appName("censusAnalysis")
    .master("local")
    .getOrCreate()

  val textOutputPath = ("/tmp/data/out/census_textOutput1")

  val seqOutputPath = ("/tmp/data/out/census_seqOutput1")

  //reading the file in wholeTextFileformat
  val wholefileRdd = spark.sparkContext.wholeTextFiles("/tmp/data/2010_Census_Populations_by_Zip_Code.csv", 2)
  val fileRdd = spark.sparkContext.textFile("/tmp/data/2010_Census_Populations_by_Zip_Code.csv", 2)
  val sc = spark.sparkContext
  val sqlContext = new SQLContext(sc)

  //import sqlContext.implicits._

  //Flatten that one record to number of records which are there in the file.
  val flattenRdd = fileRdd.flatMap(line => (line.split('_')))


  val schemaString = "zip population median males females households avgHousehold"

  //Check the partition size
  val numOfPartitions = flattenRdd.getNumPartitions

  //repartition to considerable partition
  val partitionedRdd = flattenRdd.repartition(6)

  //printing 10 elements to console
  //partitionedRdd.toDF().show(10, false)

  import org.apache.spark.sql.Row;
  import org.apache.spark.sql.types.{StructType, StructField, StringType};

  //defining the schema and converting it to RowRdd
  val schema = StructType(schemaString.split(" ").map(fieldName => StructField(fieldName, StringType, true)))
  val rowRDD = flattenRdd.map(_.split(",")).map(p => Row(p(0), p(1), p(2), p(3), p(4), p(5), p(6)))

  //creating a DataFrame out of it
  val censusDF1 = sqlContext.createDataFrame(rowRDD, schema)

  import sqlContext.implicits._
  import org.apache.spark.sql.functions._

  //adding new columns "Total Population In Millions".
  val censusDF = censusDF1.withColumn("Total Population In Millions", $"population")

  //omitting the Zip codes -- 90068,90201
  val f = Seq(90068, 90201)
  val filterZip = censusDF.filter(!censusDF("zip").isin(f: _*))

  //omitting the header
  val header = filterZip.first()
  val filterDF = filterZip.rdd.filter(row => row != header)

  //saving the file in textfile format
  filterDF.coalesce(1).saveAsTextFile(textOutputPath)

  //saving the file in sequenceFile format
   val seqRDDKey =filterDF.map(_.mkString(","))
   val seqRDDValue = seqRDDKey.map(x => (x,seqOutputPath))
  seqRDDValue.coalesce(1).saveAsSequenceFile(seqOutputPath)
}