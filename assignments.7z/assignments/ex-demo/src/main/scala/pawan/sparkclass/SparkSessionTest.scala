package pawan.sparkclass
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext._
import org.apache.spark._
object SparkSessionTest {
  def main(args:Array[String]): Unit ={

    System.setProperty("hadoop.home.dir", "c:/tmp/");
    
    // Create a SparkContext using every core of the local machine
    val conf = new SparkConf()
            .setAppName("SparkSessionTest")
            .setMaster("local")
    //create spark context object
    val sc = new SparkContext(conf)
    
    println("First SparkContext:")
    println("APP Name :"+sc.appName);
    println("Deploy Mode :"+sc.deployMode);
    println("Master :"+sc.master);

    val sparkSession = SparkSession.builder()
      .master("local[1]")
     /// .appName("SparkSessionTest-2")
      .getOrCreate();

    println("Second SparkContext:")
    println("APP Name :"+sparkSession.sparkContext.appName);
    println("Deploy Mode :"+sparkSession.sparkContext.deployMode);
    println("Master :"+sparkSession.sparkContext.master);
  }
}

