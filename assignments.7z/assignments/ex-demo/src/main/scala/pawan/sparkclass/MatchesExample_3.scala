package pawan.sparkclass

import org.apache.hadoop.io.compress.GzipCodec
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.rdd.SequenceFileRDDFunctions

import scala.reflect.macros.whitebox

object MatchesExample_3 extends App {

  System.setProperty("hadoop.home.dir", "c:/tmp/");
  val spark = SparkSession
    .builder()
    .appName("MatchesExample_3")
    .master("local")
    .getOrCreate()
    
    val sc = spark.sparkContext
    
//import CSV files to RDD

val roleRDD = sc.textFile("/tmp/data/role.csv")
val matchRDD = sc.textFile("/tmp/data/match.csv")
val playerRDD = sc.textFile("/tmp/data/player.csv")
val groundRDD = sc.textFile("/tmp/data/ground.csv")

//playerRDD.collect.foreach(println)

///3.Players who did not play even a single match , //create a set of all player numbers in player.csv
val playerRDD1=playerRDD.filter(rec => !(rec.split(",")(0)=="player_number"))

playerRDD1.collect.foreach(println)

//val playerRDD2=playerRDD1.map(rec => rec.split(",")(0)).collect().toArray.toSet
//playerRDD2.foreach(println)

val playerNo = playerRDD1.map(rec => rec.split(",")(0).toInt).collect().toArray.toSet
//playerNo.foreach(println)
println(playerNo)
val matchRDDm = matchRDD.filter(rec => !(rec.split(",")(2)=="Runs"))
matchRDDm.collect.foreach(println)

//create a set of distinct player numbers from match.csv
//val playerPlayed = matchRDDm.map(rec => rec.split(",")(1).toInt).collect().distinct.toArray.toSet
val playerPlayed = matchRDDm.map(rec => rec.split(",")(1).toInt).collect().toArray.toSet
//playerPlayed.foreach(println)

//get the difference of sets and convert to string
 //Set(5, 10, 24, 25, 14, 20, 29, 1, 6, 28, 21, 9, 13, 2, 17, 22, 27, 12, 7, 3, 18, 16, 11, 26, 23, 8, 19, 4, 15)
 //Set(5, 10, 24, 25, 14, 20, 29, 1, 6, 28, 21, 9, 13, 2, 17, 22, 27, 12, 7, 3, 18, 16, 11, 23, 8, 19, 4, 15)
val notPlayed = (playerNo &~ playerPlayed).mkString
//notPlayed.foreach(println)
println(playerNo)
println(playerPlayed)
println("Not Played :\n"+notPlayed)
//get player details from playerRDD1
val playerName  = playerRDD1.filter(rec => rec.split(",")(0) == notPlayed)
playerName.collect.foreach(println)

//26,Broad,26-08-1991,London,England

}