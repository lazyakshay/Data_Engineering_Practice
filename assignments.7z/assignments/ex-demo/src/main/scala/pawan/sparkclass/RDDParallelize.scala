//2
package pawan.sparkclass


import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object RDDParallelize {

  def main(args: Array[String]): Unit = {
       System.setProperty("hadoop.home.dir", "c:/tmp/");

      val spark:SparkSession = SparkSession.builder().master("local[1]")
          .appName("RDDParallelize")
          .getOrCreate()
      val rdd:RDD[Int] = spark.sparkContext.parallelize(List(1,2,3,4,5))
      //val rdd:RDD[Int] = spark.sparkContext.parallelize(Seq.empty[String])

      val rddCollect:Array[Int] = rdd.collect()
      println("Number of Partitions: "+ rdd.getNumPartitions)
      println("Action: First element: "+rdd.first())
      println("Action: RDD converted to Array[Int] : ")
      rddCollect.foreach(println)
  }
}