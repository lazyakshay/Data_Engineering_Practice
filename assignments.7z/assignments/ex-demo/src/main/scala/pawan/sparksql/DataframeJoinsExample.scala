package pawan.sparksql

import org.apache.spark.sql.catalyst.plans._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object DataframeJoinsExample {
  
def main(args: Array[String]) {
  

val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()

      //val emp = spark.read.csv("D:/hadoop/data/employee.txt")
      val emp = Seq((1,"Smith",-1,"2018","10","M",3000),
    (2,"Rose",1,"2010","20","M",4000),
    (3,"Williams",1,"2010","10","M",1000),
    (4,"Jones",2,"2005","10","F",2000),
    (5,"Brown",2,"2010","40","",-1),
      (6,"Brown",2,"2010","50","",-1)
  )
  val empColumns = Seq("emp_id","name","superior_emp_id","year_joined",
       "emp_dept_id","gender","salary")
  import spark.sqlContext.implicits._
  val empDF = emp.toDF(empColumns:_*)
  empDF.show(false)

  //val dept = spark.read.csv("D:/hadoop/data/dept.txt")
  val dept = Seq(("Finance",10),
    ("Marketing",20),
    ("Sales",30),
    ("IT",40)
  )

  val deptColumns = Seq("dept_name","dept_id")
  val deptDF = dept.toDF(deptColumns:_*)
  deptDF.show(false)
  
  //Inner Join
  //Inner join is the default join in Spark and it’s mostly used, this joins two datasets on key columns and 
  //where keys don’t match the rows get dropped from both datasets
  println("Inner join")
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"inner")
  .show(false)
  
  //Outer, Full, Fullouter Join [same thing]
  //Outer a.k.a full, fullouter join returns all rows from both datasets, where join expression doesn’t match it 
  //returns null on respective record columns
  println("Full outer join")
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"outer")
    .show(false)
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"full")
    .show(false)
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"fullouter")
    .show(false)
    
  //Left, Leftouter Join
  //Left a.k.a Leftouter join returns all rows from the left dataset regardless of match found on the right dataset 
  //when join expression doesn’t match, it assigns null for that record and drops records from right where match not found.
    println("Left Outer join")
     empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"left")
    .show(false)
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"leftouter")
    .show(false)
    
  //Righ, Rightouter Join
  //Right a.k.a Rightouter join is opposite of left join, here it returns all rows from the right dataset 
  //regardless of math found on the left dataset, when join expression doesn’t match, it assigns null for that 
   //record and drops records from left where match not found.
  println("Right Outer join")
    empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"right")
   .show(false)
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"rightouter")
   .show(false)
   
   //Left Semi Join
   //leftsemi join is similar to inner join difference being leftsemi join returns all columns from the left 
   //dataset and ignores all columns from the right dataset. In other words, this join returns columns from the 
   //only left dataset for the records match in the right dataset on join expression, records not matched on join 
   //expression are ignored from both left and right datasets.
   
   //same result can be achieved using select on the result of the inner join however, using this join would be efficient.
   println("Left Semi join")
   empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"leftsemi")
    .show(false)
   
    
    //Left Anti Join
    //leftanti join does the exact opposite of the leftsemi, leftanti join returns only columns 
    //from the left dataset for non-matched records.
    println("Left Anti join")
    empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),"leftanti")
    .show(false)
    
    //Self Join
    //Joins are not complete without a self join, Though there is no self-join type available, 
    //we can use any of the above-explained join types to join DataFrame to itself. below example use inner self join
    
    
    println("Self join")
     empDF.as("emp1").join(empDF.as("emp2"),
          col("emp1.superior_emp_id") === col("emp2.emp_id"),"inner")
    .select(col("emp1.emp_id"),col("emp1.name"),
      col("emp2.emp_id").as("superior_emp_id"),
      col("emp2.name").as("superior_emp_name"))
      .show(false)
   
      //Using Join Types... org.apache.spark.sql.catalyst.plans
      
      
    import org.apache.spark.sql.catalyst.plans.{Inner}

  println("Inner join")
  empDF.join(deptDF,empDF("emp_dept_id") ===  deptDF("dept_id"),Inner.sql)
  .show(false)
    
}
}