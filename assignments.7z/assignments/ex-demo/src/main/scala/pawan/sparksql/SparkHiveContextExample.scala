package pawan.sparksql
 
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext
import  org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.functions._
 
/**
  * Spark Hive Context Example 
  */
/*
 employee.txt

1201, satish, 25
1202, krishna, 28
1203, amith, 39
1204, javed, 23
1205, prudvi, 23
*/

object SparkHiveContextExample {
 
  def main(args: Array[String]) {

    val conf = new SparkConf()
            .setAppName("SparkHiveContextExample")
            .setMaster("local")
    val spark = new SparkContext(conf)
    val hiveContext = new HiveContext(spark)
    hiveContext.sql("CREATE TABLE IF NOT EXISTS employee(id INT, name STRING, age INT) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n'")
    hiveContext.sql("LOAD DATA LOCAL INPATH '/data/employee.txt' INTO TABLE employee")
    val result = hiveContext.sql("FROM employee SELECT id, name, age")
    result.show();
    spark.stop()
  }
 
}