package pawan.sparksql
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
object FromXMLFile {
  def main(args:Array[String]): Unit = {
    
    System.setProperty("hadoop.home.dir", "D:/hadoop/");
    
    val spark: SparkSession = SparkSession.builder()
      .master("local[3]")
      .appName("FromXMLFile")
      .getOrCreate()
  
  val df = spark.read
      .format("com.databricks.spark.xml")
      .format("xml")
      .option("rowTag", "person")
      .load("D:/hadoop/resources/persons.xml")
     
      df.printSchema()
      df.show(false);
    
    val schema = new StructType()
      .add("_id",StringType)
      .add("firstname",StringType)
      .add("middlename",StringType)
      .add("lastname",StringType)
      .add("dob_year",StringType)
      .add("dob_month",StringType)
      .add("gender",StringType)
      .add("salary",StringType)
  
   val df1 = spark.read
  .option("rowTag", "person")
  .format("xml")
  .schema(schema)
  .load("D:/hadoop/resources/persons.xml")
  df1.show()
    
  df.createOrReplaceTempView("persons")
  spark.sql("select addresses from persons").show(false)
  
  
  }
}