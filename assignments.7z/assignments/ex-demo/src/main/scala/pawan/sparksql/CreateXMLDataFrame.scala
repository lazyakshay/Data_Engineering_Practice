package pawan.sparksql

import org.apache.spark.sql.{SparkSession}


object CreateXMLDataFrame {
  def main(args:Array[String]):Unit={
    
    System.setProperty("hadoop.home.dir", "c:/tmp/");
    
    val spark:SparkSession = SparkSession.builder()

      .master("local[1]")
      .appName("CreateXMLDataFrame")
      .getOrCreate()

      
val df = spark
    .read
    .format("com.databricks.spark.xml")
    .option("rowTag", "person")
    .load("/tmp/resources/persons.xml")
    df.show()
    

  }

}