package pawan.sparksql
 
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._
 
/**
  * Spark SQL with JDBC Example 
  */
object SparkSQLJDBCApp {
 
  def main(args: Array[String]) {

    val conf = new SparkConf().setAppName("SparkSQLJDBCApp").setMaster("local")
    val spark = new SparkContext(conf)
    val sqlContext = new SQLContext(spark)

//    val dataframe_mysql = sqlContext.read.format("jdbc").
//                            option("url", "jdbc:mysql://localhost/world").
//                            option("driver", "com.mysql.jdbc.Driver").
//                            option("dbtable", "city").
//                            option("user", "root").option("password", "root").load()

    val dataframe_mysql = sqlContext.read.format("jdbc").
                            option("url", "jdbc:postgresql://server1.databricks.training:5432/training").
                            option("driver", "org.postgresql.Driver").
                            option("dbtable", "people_1m").
                            option("user", "readonly").option("password", "readonly").load()
    dataframe_mysql.createOrReplaceTempView("names")

    println("Result of query:")
    dataframe_mysql
      .sqlContext
      .sql("select * from names")
      .collect
      .foreach(println)
    dataframe_mysql.show(10)
    dataframe_mysql
        .rdd
        .saveAsTextFile("/tmp/data/out/world_city")
    spark.stop()
  }
 
}
