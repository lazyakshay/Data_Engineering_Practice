package pawan.sparksql

import org.apache.spark.sql._
import org.apache.spark.sql.functions.col


object CacheExample extends App{
  val spark: SparkSession = SparkSession.builder()
    .master("local[1]")
    .appName("CacheExample")
    .getOrCreate()

  spark.sparkContext.setLogLevel("ERROR")

 val df =  spark.read
          .options(Map("inferSchema"->"true",
                      "delimiter"->",","header"->"true"))  
          .csv("/tmp/resources/zipcodes.csv") 
  val df2 = df.where(col("State") === "PR").cache()
  df2.show(false) 
  println(df2.count()) 
  
  val df3 = df2.where(col("Zipcode") === 704) 
  println(df2.count() )
  
  
  
}    