package pawan.sparksql
 
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StructType,StructField}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.IntegerType

 
// Nested CSV to PArquet File

object ReadNestedParquet {
 
  def main(args: Array[String]) {

       System.setProperty("hadoop.home.dir", "c:/tmp/");
    val spark: SparkSession = SparkSession
                  .builder()
                  .master("local[1]")
                  .appName("ReadNestedParquet")
                  .getOrCreate()
         
    val sqlContext= new SQLContext(spark.sparkContext)
    //val data = sqlContext.read.parquet("/tmp/data/out/out8/")
    val schema = StructType(
    List(
    StructField("name", StringType, true),
    StructField("age", IntegerType, true),
    StructField("address", StringType, true),
    StructField("phone", IntegerType, true)
  )
)
        val data = sqlContext
              .read
              .format("parquet")
              .schema(schema)
              .load("D:/hadoop/output/out10/datanested.parquet")
    data.printSchema()
    data.show(false)
   import spark.implicits._
     val newDF = data.map(f=>{
  val name = f.getAs[String](0)
  val age = f.getAs[Int](1)
  val add = f.getAs[String](2).split("#")
  val phone = f.getAs[Int](3)
      (name,age,add(0),add(1),add(2),phone)
    })
  val finalDF = newDF.toDF("name","age","Address Line1","City","State","phone")
  finalDF.printSchema()
  finalDF.show(false)
  
    

  
    spark.close()
  }
 
}