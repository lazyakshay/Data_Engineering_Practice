package pawan.sparksql


object PivotExample {
  
def main(args: Array[String]) {
  
import org.apache.spark.sql._
System.setProperty("hadoop.home.dir", "D:/hadoop/");
val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()

val df=spark.read.option("header",false).csv("D:/hadoop/data/productPivot.csv")
df.show(false)

import spark.sqlContext.implicits._
val cdf = df.toDF("Product","Amount","Country")
cdf.show()


import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
val pivotDF = cdf
                .withColumn("Amt",col("Amount").cast(IntegerType))
               .groupBy("Product").pivot("Country").sum("Amt")
             
     pivotDF.show()

}

}