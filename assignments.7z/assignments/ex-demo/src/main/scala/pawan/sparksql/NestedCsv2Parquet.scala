package pawan.sparksql
 
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._
 
// Nested CSV to Parquet File

object NestedCsv2Parquet {
 
  def main(args: Array[String]) {

    System.setProperty("hadoop.home.dir", "c:/tmp/");
    val spark: SparkSession = SparkSession
                  .builder()
                  .master("local[1]")
                  .appName("NestedCsv2Parquet")
                  .getOrCreate()
                  
    
    val sqlContext= new SQLContext(spark.sparkContext)
    
     val data = sqlContext.read.format("com.databricks.spark.csv")
                        .option("header", "true")
                        .option("inferSchema", "true")
                        .load("/tmp/data/datanested.csv")
    //Using inferSchema=false (default option) will give a dataframe where all columns are strings ( StringType ).
    //Depending on what you want to do, strings may not work. For example, if you want to add numbers from different 
    //columns, then those columns should be of some numeric type (strings won't work)
                        
    data.show(false);
    //If you put data.show(false) , results will not be truncated on long columns
    //data.registerTempTable("datat")
    data.createOrReplaceTempView ("datat")
    data.sqlContext.sql("select name,age,address,phone from datat").show()
    
    
    import spark.implicits._

  val newDF = data.map(f=>{
  val name = f.getAs[String](0)
  val age = f.getAs[Int](1)
  val add = f.getAs[String](2).split("#")
  val phone = f.getAs[Int](3)
  
  
      (name,age,add(0),add(1),add(2),phone)
    })
  val finalDF = newDF.toDF("name","age","Address Line1","City","State","phone")
  finalDF.printSchema()
  finalDF.show(false)
  data.write.parquet("/tmp/data/out/out8/datanested.parquet")
  spark.close();
    
    
  }
 
}