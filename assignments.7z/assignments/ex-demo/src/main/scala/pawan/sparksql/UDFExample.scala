package pawan.sparksql

object UDFExample {
  
def main(args: Array[String]) {
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
 //The first step in creating a UDF is creating a Scala function.
val convertCase =  (strQuote:String) => {
    val arr = strQuote.split(" ")
    arr.map(f=>  f.substring(0,1).toLowerCase() + f.substring(1,f.length)).mkString(" ")
}

import org.apache.spark.sql.functions.udf

import org.apache.spark.sql._

val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()

val df=spark.read.option("header",true).csv("D:/hadoop/data/Order.csv")
df.show(false)
 
//Now convert this function convertCase() to UDF by passing the function to Spark SQL udf(), this function is available at
val convertUDF = udf(convertCase)

import org.apache.spark.sql.functions._
df.withColumn("newgender",convertUDF(col("gender"))).show(false)

// Using it on SQL
spark.udf.register("convertUDF", convertCase)
df.createOrReplaceTempView("order_table")
spark.sql("select oid, convertUDF(gender) as newgender from order_table").show(false)

//UDF’s are error-prone when not designed carefully. for example, when you have a column that contains 
//the value null on some records and not handling null inside a UDF function returns error.

}

}