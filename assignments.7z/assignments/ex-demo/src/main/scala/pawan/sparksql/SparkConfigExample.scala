package pawan.sparksql

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

// Visit https://spark.apache.org/docs/latest/configuration.html

object SparkConfigExample extends App {
System.setProperty("hadoop.home.dir", "c:/tmp/");
  
  
  val spark = SparkSession.builder
  .config("spark.master","local[2]")
  .config("spark.driver.memory","2g")
  .config("spark.app.name","SparkConfigExample")
  .config("spark.executor.memory", "2g")
  .config("spark.executor.cores", "2")
  .config("spark.cores.max", "2")
  .getOrCreate()
  
  spark.sparkContext.getConf.getAll.foreach(println)
  
  println()    
  val df2 = spark.read.csv("/tmp/resources/kv.csv")
  df2.show
  val x=df2.select("_c1").filter("_c0='record1'").collect()
  x.foreach(println)

  
}