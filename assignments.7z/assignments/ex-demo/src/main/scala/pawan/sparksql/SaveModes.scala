package pawan.sparksql

/**
  * Spark Save Modes 
  */

import org.apache.spark.sql._

object SaveModes {
 
  def main(args: Array[String]) {
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
 
val spark = SparkSession 
             .builder() 
             .appName("Spark SQL basic example") 
             .master("local")
             .getOrCreate()
 // val sqlDF = spark.sql("SELECT * FROM parquet.`/tmp/resources/users.parquet`")
  val sqlDF = spark.read.csv("D:/hadoop/data/Order.csv")
 
  
  sqlDF.show()
  
  sqlDF.write.format("csv")
  //.mode(SaveMode.Overwrite)  // First time without Mode and Later with mode
  //.mode(SaveMode.Append)
 // .mode(SaveMode.ErrorIfExists)
  .mode(SaveMode.Ignore)
  .save("D:/hadoop/output/out13/order.csv"); 


  // ACID

  }
 
}