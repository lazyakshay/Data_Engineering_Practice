package pawan.sparksql

/**
  * Spark Save Modes 
  */

import org.apache.spark.sql._

object SaveModesCSV {
 
  def main(args: Array[String]) {

 
val spark = SparkSession 
             .builder() 
             .appName("Spark SQL basic example") 
             .master("local")
             .getOrCreate()
  //val sqlDF = spark.read.csv("/tmp/data/files/text01.txt")
  //val sqlDF = spark.read.csv("/tmp/data/files/text02.txt")
  //val sqlDF = spark.read.csv("/tmp/data/files/text03.txt")
  val sqlDF = spark.read.csv("/tmp/data/files/text04.txt")
  //val sqlDF = spark.read.csv("/tmp/data/files/text05.txt")
  
   sqlDF.write.format("csv")
  .mode(SaveMode.Overwrite)  // First time without Mode and Later with mode
  .save("/tmp/data/out/savemodecsv"); 
                   
  }
 
}