package pawan.sparksql

/**
  * Spark Save Modes PartitionBy 
  */

import org.apache.spark.sql._

object SaveModesCSV_PartitionBy {
 
  def main(args: Array[String]) {

  System.setProperty("hadoop.home.dir", "c:/tmp/");
val spark = SparkSession 
             .builder() 
             .appName("Spark SQL basic example") 
             .master("local")
             .getOrCreate()
  val sqlDF = spark
          .read
          .option("header", "true")
          .csv("/tmp/data/Order.csv")
          sqlDF.show(false)
  
          /// transformations................
          
  sqlDF
    //.repartition(5)
    .write.partitionBy("country")
    .format("csv")
    .mode(SaveMode.Overwrite) 
    .save("/tmp/data/out/Orders"); 
                   
  
//   sqlDF
//    //.repartition(1)
//    .write
//    .mode(SaveMode.Append)
//    .partitionBy("country")
//    .format("parquet")
//    .save("/tmp/data/out/Orders")
//    
 //Check
 //val sqlDFfinal = spark.read.parquet("/tmp/data/out/Orders")
 //sqlDFfinal.show(false)

  
    
  }
 
}