package pawan.sparksql

import org.apache.spark.sql._

object test {
  
   def main(args: Array[String]) {
    // $example on:init_session$
     
    System.setProperty("hadoop.home.dir", "D:/hadoop/")
    val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      //.config("spark.some.config.option", "some-value")
      .getOrCreate()
      
      val df=spark
                .read
                .option("header",true)
                .csv("D:/hadoop/data/Order.csv")
      df.show()
   }
}