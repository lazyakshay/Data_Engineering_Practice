package exercise1

import org.apache.hadoop.io.compress.GzipCodec
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.rdd.SequenceFileRDDFunctions

import scala.reflect.macros.whitebox

object MatchesExample_2 extends App {

  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  val spark = SparkSession
    .builder()
    .appName("MatchesExample_2")
    .master("local")
    .getOrCreate()
    
    val sc = spark.sparkContext
    
//import CSV files to RDD
val roleRDD = sc.textFile("D:/hadoop/data/role.csv")
val matchRDD = sc.textFile("D:/hadoop/data/match.csv")
val playerRDD = sc.textFile("D:/hadoop/data/player.csv")
val groundRDD = sc.textFile("D:/hadoop/data/ground.csv")


//filter matchRDD to filter out scores greater than 50 and then map it into tuple (groundnumber,Playernumber)
val matchRDDm = matchRDD.filter(rec => !(rec.split(",")(2)=="Runs"))
matchRDDm.collect.foreach(println)

val matchRDDMap = matchRDDm.filter(rec => !rec.split(",")(2).isEmpty && rec.split(",")(2).toInt > 50).map(rec => (rec.split(",")(4), rec.split(",")(1)))
matchRDDMap.collect.foreach(println)
//groundnumber,Playernumber
//(1,4)

//mapping groundRDD to tuple (groundNo,place)
val groundRDDMap = groundRDD.map(rec => (rec.split(",")(0), rec.split(",")(1)))
groundRDDMap.collect.foreach(println)
//groundNo,place
//(1,Bangalore)

//joining groundRDDMap with matchRDDMap to get the groundNames and then forming tuple (playerNo, groundName)
val groundJoinMatch = groundRDDMap.join(matchRDDMap).map(rec => (rec._2._2, rec._2._1))
groundJoinMatch.collect.foreach(println)
//playerNo, groundName
//(4,Kolkata)

//mapping playerRDD to tuple (playerNo,(Name,Hometown))
val playerRDDMap = playerRDD.map(rec => (rec.split(",")(0), (rec.split(",")(1), rec.split(",")(3))))
playerRDDMap.collect.foreach(println)

//joining groundJoinMatch and playerRDDMap on playerno and then filter where hometown == groundName
val finalJoin = groundJoinMatch.join(playerRDDMap).filter(rec => rec._2._1 == rec._2._2._2).map(rec => (rec._2._2._1, rec._2._1))
finalJoin.collect.foreach(println)
//(Rahul,Delhi)
//(Kohli,Delhi)

}