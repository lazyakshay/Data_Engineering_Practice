package exercise1

import org.apache.hadoop.io.compress.GzipCodec
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.rdd.SequenceFileRDDFunctions

import scala.reflect.macros.whitebox

object MatchesExample_4 extends App {

  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  val spark = SparkSession
    .builder()
    .appName("MatchesExample_4")
    .master("local")
    .getOrCreate()
    
    val sc = spark.sparkContext
    
//import CSV files to RDD
val roleRDD = sc.textFile("D:/hadoop/data/role.csv")
val matchRDDf = sc.textFile("D:/hadoop/data/match.csv")
val playerRDD = sc.textFile("D:/hadoop/data/player.csv")
val groundRDD = sc.textFile("D:/hadoop/data/ground.csv")


val matchRDD = matchRDDf.filter(rec => !(rec.split(",")(2)=="Runs"))
matchRDD.collect.foreach(println)

val highestRuns = matchRDD.filter(rec => !rec.split(",")(2).isEmpty).map(rec => (rec.split(",")(1), rec.split(",")(2).toInt)).reduceByKey(_+_).reduce((x,y) => (if (x._2 >= y._2) x else y))

val playerDetails = playerRDD.filter(rec => rec.split(",")(0) == highestRuns._1)

playerDetails.collect.foreach(println)
//19,Bairstow,30-05-1988,London,England

val highestWickets = matchRDD.filter(rec => !rec.split(",")(3).isEmpty).map(rec => (rec.split(",")(1), rec.split(",")(3).toInt)).reduceByKey(_+_).reduce((x,y) => (if (x._2 >= y._2) x else y))

val playerWickets = playerRDD.filter(rec => rec.split(",")(0) == highestWickets._1)
playerWickets.collect.foreach(println)

//22,Moen,20-12-1989,Birmingham,England

}