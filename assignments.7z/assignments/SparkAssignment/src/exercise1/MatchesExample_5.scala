package exercise1

import org.apache.hadoop.io.compress.GzipCodec
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.rdd.SequenceFileRDDFunctions

import scala.reflect.macros.whitebox

object MatchesExample_5 extends App {

  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  val spark = SparkSession
    .builder()
    .appName("MatchesExample_5")
    .master("local")
    .getOrCreate()
    
    val sc = spark.sparkContext
    
//import CSV files to RDD
val roleRDD = sc.textFile("D:/hadoop/data/role.csv")
val matchRDDf = sc.textFile("D:/hadoop/data/match.csv")
val playerRDDf = sc.textFile("D:/hadoop/data/player.csv")
val groundRDD = sc.textFile("D:/hadoop/data/ground.csv")

val matchRDD = matchRDDf.filter(rec => !(rec.split(",")(2)=="Runs"))
matchRDD.collect.foreach(println)

val playerRDD=playerRDDf.filter(rec => !(rec.split(",")(0)=="player_number"))
playerRDD.collect.foreach(println)

// importing joda time library
import org.joda.time._
//get todays date
val now = new DateTime()
val today = now.toLocalDate()

//function to calculate age
 def calcAge(dob:String, today:LocalDate): Int = {
      val dateSplit = dob.split("/|-")
      val dobDate = new LocalDate(dateSplit(2).toInt, dateSplit(1).toInt, dateSplit(0).toInt)
      val days = Days.daysBetween(dobDate, today).getDays()
      return days
      }
//
val playerMap = playerRDD.map(rec => (rec.split(",")(0), (rec.split(",")(1), calcAge(rec.split(",")(2),today))))
playerRDD.foreach(println)

val matchMap = matchRDD.filter(rec => !rec.split(",")(2).isEmpty && rec.split(",")(2).toInt >= 100).map(rec => (rec.split(",")(1), rec.split(",")(2)))
matchMap.foreach(println)
val playerJoinMatch = playerMap.join(matchMap).map(rec => (rec._2._1._1, rec._2._1._2))
playerJoinMatch.foreach(println)
val oldestPlayerCentury = playerJoinMatch.reduce((x,y) => (if (x._2 >= y._2) x else y))
println(oldestPlayerCentury)
//(String, Int) = (Pujara,11366)



}