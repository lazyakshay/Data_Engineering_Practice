package largedata

import java.io.FileWriter;
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._

object ObjEmp {
  
  case class Person(name:String, age:Int, salary:Int)
  
  
  def main(args: Array[String]){
    System.setProperty("hadoop.home.dir", "D:/hadoop/")
    val spark = SparkSession
      .builder()
      .appName("UpperCase-Akshay")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()
      
    
    if (args.length < 2) {
      println("Usage: UpperCase <input> <output>")
      System.exit(1)
    } 
    
    import spark.implicits._
    
    //val df = spark.read.csv("D:/hadoop/largedata/employee.csv")
    
    val schema = new StructType().add(StructField("name", StringType, true)).add(StructField("age", StringType, true)).add(StructField("salary", StringType, true))
    
   // val df = spark.read.format("csv").schema(schema).load("D:/hadoop/largedata/employee.csv")
    val df = spark.read.format("csv").schema(schema).load(args(0))
   // df.show()
  
    val dfName = df.select("name").map(ele => ele.getString(0).toUpperCase())
    dfName.write.save(args(1))
   // dfName.collect.foreach(println)
   // dfName.saveAsTextFile(args(1))
    
    
    spark.stop()
  }
}