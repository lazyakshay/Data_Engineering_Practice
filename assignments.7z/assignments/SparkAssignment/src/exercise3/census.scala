package exercise3

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object census extends App {
  
  System.setProperty("hadoop.home.dir", "D:/hadoop/")
  
  val conf = new SparkConf()
  .setAppName("Akshay-exa3")
  .setMaster("local")
  
  val sc = new SparkContext(conf)
  
  val fileRDD = sc.wholeTextFiles("D:/hadoop/data/2010_Census_Populations_by_Zip_Code.csv", 2)
  //fileRDD.foreach(println)
  
  val fileRDDFlat = fileRDD.flatMap(line => line._2.split("\n"))
  //fileRDDFlat.foreach(println)
  
  //total population //////
  val fileRDDfilter = fileRDDFlat.filter(line => !(line.split(",")(1)=="Total Population"))
  val fileRDDmap = fileRDDfilter.map(line => line.split(",")(1).toInt)
  //fileRDDmap.collect.foreach(println)
  val totalPop = fileRDDmap.reduce((a,b) => a+b)
  println("Total population in millions: " + totalPop) 
  
  //doubt RDD immutable
  
  //get partition
  val part = fileRDDFlat.getNumPartitions
  println("Number of Partition is: " + part)
  val partRDD = fileRDDFlat.repartition(4)
  val part1 = partRDD.getNumPartitions
  println("Number of Partition is: " + part1)
  
  val topten = partRDD.take(10)
  //val topten = partRDD.top(10)
  topten.foreach(println)
  
  //saving into files
  val filterPartRDD = partRDD.filter(line => !(line.split(",")(0) == "Zip Code" | line.split(",")(0) == "90068" | line.split(",")(0) == "90201"))
  filterPartRDD.saveAsTextFile("D:/hadoop/output/censustext1")
  
  //sequence files
  val seqRDDValue = filterPartRDD.map(x => (x,"D:/hadoop/output/census2"))
  seqRDDValue.saveAsSequenceFile("D:/hadoop/output/census2")
  
}