package exercise2

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf


object superhero extends App {
  
  System.setProperty("hadoop.home.dir", "D:/hadoop/")
  
  val conf = new SparkConf()
  .setAppName("Akshay-exa2")
  .setMaster("local")
  
  val sc = new SparkContext(conf)
  
  val names = sc.textFile("D:/hadoop/data/Marvel-names.txt")
  val graphs = sc.textFile("D:/hadoop/data/Marvel-graph.txt")
  
  val namesRDD = names.map(line => line.split("\"").toList)
  val namesmap = namesRDD.map(line => (line(0).trim().toInt, ({
    if(line.length > 1) {
      line(1).split("/").toList(0)
    }
  })))
 // namesmap.foreach(println)
  
  val graphsmap = graphs.map(line => {
    val temp = line.split(" ")
    (temp(0), temp.length-1)
  })
  val mostconnection = graphsmap.reduce((a,b) => {
    if(a._2 > b._2) a
    b
  })
  println(mostconnection)
  val superHero = mostPop(namesmap)
  println(s"$superHero is the most popular superhero with ${mostconnection._2} co-appearances.")
  
  import org.apache.spark.rdd.RDD
  def mostPop(names:RDD[(Int, Any)]) : String = {
    var res = ""
    names.foreach(item => {
      if(item._1 == mostconnection._1.toInt) {
        res = item._2.toString()
        println(res)
      }
    })
    res
  }
  
}