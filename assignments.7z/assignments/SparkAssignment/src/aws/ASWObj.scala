package aws


import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object ASWObj {
  def main(args: Array[String]) {
    val conf = new SparkConf()
    .setAppName("Akshay-check")
    
    val sc = new SparkContext(conf)
    
    sc.hadoopConfiguration.set("fs.s3a.access.key", "AKIAU3NO6VSNNO7CET54")
    sc.hadoopConfiguration.set("fs.s3a.secret.key", "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")
    sc.hadoopConfiguration.set("fs.s3a.endpoint", "vpce-0fe394f320fa760d7")
    val rddFromFile = sc.textFile("s3://tavent-training-fileload/akshay/input/")
    rddFromFile.collect
    rddFromFile.saveAsTextFile("s3://tavent-training-fileload/akshay/output/out2")
  }
}