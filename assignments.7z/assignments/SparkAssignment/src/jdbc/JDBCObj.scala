package jdbc

import java.util.Properties
import org.apache.spark.sql.SparkSession
import java.sql.DriverManager
import java.sql.Connection

object JDBCObj {
  
  def main(args: Array[String]) {
     System.setProperty("hadoop.home.dir", "D:/hadoop/");
     
      val spark = SparkSession
      .builder()
      .appName("Spark JDBC example")
      .config("spark.some.config.option", "some-value")
      .master("local")
      .getOrCreate()
    
      
      runJdbcDatasetExample(spark)
  }
  
  private def runJdbcDatasetExample(spark: SparkSession): Unit = {
    println("JDBC starting..")
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://localhost:3306/sys"
    val username = "root"
    val password = "root"
    
    
    val jdbcDF = spark.read
      .format("jdbc")
      .option("url", url)
      .option("dbtable", "sys.employee")
      .option("user", username)
      .option("password", password)
      .load()
      
     //jdbcDF.show() 

    val connectionProperties = new Properties()
    connectionProperties.put("user", username)
    connectionProperties.put("password", password)
    val jdbcDF2 = spark.read
      .jdbc(url, "sys.employee", connectionProperties)
     // jdbcDF2.show()
      
    // Specifying the custom data types of the read schema
    connectionProperties.put("customSchema", "id Int, name STRING, dept String, salary DECIMAL(20,2)")
    val jdbcDF3 = spark.read
      .jdbc(url, "sys.employee", connectionProperties)
     // jdbcDF3.show()

    // Saving data to a JDBC source
    jdbcDF.write
      .format("jdbc")
      .option("url", url)
      .option("dbtable", "sys.emp1")
      .option("user", username)
      .option("password", password)
      .save()

    jdbcDF2.write
      .jdbc(url, "sys.emp2", connectionProperties)

    // Specifying create table column data types on write
    jdbcDF.write
      .option("createTableColumnTypes", "id int, name varchar(20), dept varchar(20), salary decimal(20,2)")
      .jdbc(url, "sys.emp3", connectionProperties)
    // $example off:jdbc_dataset$
  }
}