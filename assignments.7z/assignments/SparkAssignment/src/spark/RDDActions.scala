package spark

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.plans._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object RDDActions extends App {
  
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  
  val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()
  
  val conf = new SparkConf()
  .setAppName("Actions Example")
  .setMaster("local")
  val sc = new SparkContext(conf)
  
  import spark.sqlContext.implicits._
  val rdd1 = sc.textFile("D:/hadoop/data/employee.txt")
  val DF1 = spark.read.csv("D:/hadoop/data/employee.txt")
  val DS1 = rdd1.toDS()
  
}