package spark

import org.apache.spark.sql.functions.udf
import org.apache.spark.sql._

object UDF2 extends App{
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  
  val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .master("local")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()
      
   
  val df=spark.read.option("header",true).csv("D:/hadoop/data/emp.csv")
  df.show(false)
  
  import org.apache.spark.sql.functions._
  df.withColumn("newDept",convertUDF(col("dept"))).show(false)
  
  val converRank =  (strQuote:String) => {
    val arr = strQuote.split(",")
    arr.map(f=>  f.substring(0,1).toLowerCase() + f.substring(1,f.length)).mkString(" ")
   }
  
  val convertUDF = udf(converRank)
  
  spark.udf.register("convertUDF", converRank)
  df.createOrReplaceTempView("emp")
  spark.sql("select id,name,age,dept, convertUDF(dept) as newDept from emp").show(false)
  
}