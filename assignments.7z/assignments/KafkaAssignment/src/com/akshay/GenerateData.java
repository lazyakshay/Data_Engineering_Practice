package com.akshay;

import java.io.FileWriter;
import java.util.Random;

import com.opencsv.CSVWriter;

class Employee {
	String name;
	int age;
	double salary;
	
	Employee(String name, int age, int salary) {
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return new StringBuilder().append(this.name + "," + this.age + "," + this.salary).toString();
	}
}
public class GenerateData {
	
	public static String randName() {
		String str = "abcdefhghijklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<10; i++) {
			int index = new Random().nextInt(26);
			sb.append(str.charAt(index));
		}
		return sb.toString();
	}
	
	public static void main(String[] args) {
		
		System.out.println("Generating Data...");
		Random rand = new Random();
		try {
			CSVWriter writer = new CSVWriter(new FileWriter("D:/hadoop/largedata/employee.csv"));
			for(int i=0; i<9990000; i++) {
				String name = randName();
				int age = rand.nextInt(100);
				int salary = rand.nextInt(1000000);
				Employee emp = new Employee(name,age,salary);
				String[] data = emp.toString().split(",");
				writer.writeNext(data);
			}
			writer.close();
		} catch(Exception ex) {
			System.out.println("Exception occur " + ex);
		}
		
		System.out.println("Completed...");
	}
}
