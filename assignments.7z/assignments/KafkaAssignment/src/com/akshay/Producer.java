package com.akshay;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.opencsv.CSVReader;

public class Producer {
	
	public static void main(String[] args) {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        KafkaProducer<String, String> producer = new KafkaProducer<>(props);
        System.out.println("Reading csv file..");
        try {
        	/* using CSVReader */
        	CSVReader reader = new CSVReader(new FileReader("D:/TAVANT/Training/Day5/Assignment/Order.csv"));
        	String[] result;
        	while((result = reader.readNext()) != null) {
        		StringBuilder data = new StringBuilder();
        		for(String tmp : result) {
        			data.append(tmp + ";");
        		}
        		ProducerRecord<String, String> record = new ProducerRecord<>("Kafka-Assignment", data.toString());
        		producer.send(record);
        		System.out.println("sent: " + data.toString());
        	}
        } catch (Exception ex) {
        	System.out.println(ex);
        }
        producer.close();
    }

}
