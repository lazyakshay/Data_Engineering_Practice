package com.akshay;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.opencsv.CSVWriter;

public class Consumer {
	
	public static void main(String[] args) {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", "mygroup");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
       // props.put("consumer.timeout.ms", "10000");  //timeout

        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList("Kafka-Assignment"));
        
//        long start = System.currentTimeMillis();
//        long end = start + 10*1000;   //change time here (10 seconds)
        System.out.println("Consumer Started");
        //boolean running = true;
        try {
        	CSVWriter writer = new CSVWriter(new FileWriter("D:/TAVANT/Training/Day5/Assignment/OrderOutput.csv"));
        	List<String[]> result = new ArrayList<>();
        	
        	//while (running) {
                ConsumerRecords<String, String> records = consumer.poll(10000);
                for (ConsumerRecord<String, String> record : records) {
                    System.out.println("Recieve: " + record.value());
                    String[] data = record.value().split(";");
                    result.add(data);
                }
               // if(System.currentTimeMillis() > end) running = false;
           // }
        	
        	writer.writeAll(result);
        	writer.flush();
        	writer.close();
        } catch(Exception ex) {
        	System.out.println(ex);
        }
        
        System.out.println("Consumer Stopped");
        consumer.close();
    }
}
