package com.zomato.assignment

import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions.Window
import java.util.Properties
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord;
import java.io.PrintWriter
import java.io.File
import scala.compat.Platform.EOL

object ZomatoAnalysis {
  
  /****** main method *****/
  def main(args: Array[String]){
    System.setProperty("hadoop.home.dir", "D:/hadoop/");
    val spark = SparkSession
      .builder()
      .appName("Akshay Zomato Analysis")
      .config("spark.some.config.option", "some-value")
      .master("local")
      .getOrCreate();
    import spark.implicits._
    
    val urlExpr = "http[s]://www.zomato.com/(bangalore/|SanchurroBangalore)" +
                    "[a-zA-Z0-9@:%._\\+\\-~#?&//=]{0,256}" + "?context=.*";
    //val urlExpr = "((http|https)://)(www.)?"+ "[a-zA-Z0-9@:%._\\+~#?&//=]{2,256}\\.[a-z]"+ "{2,6}\\b([-a-zA-Z0-9@:%._\\+~#?&//=]*)"
    
    
    removeNonAscii(args)                         //remove non ascii chars from input file
    val cleanedDF = doDataCleanUp(spark, args)  //clean columns data, cast columns
    cleanedDF.persist()
    val invalidRestaurantsDF = invalidRestaurants(spark, cleanedDF, urlExpr)  //1st use case
    locationWithMostClosedRest(invalidRestaurantsDF)                          //2nd use case
    
    val ValidUrlRestaurantDF = cleanedDF.filter($"url" rlike urlExpr)
                                        .drop("url");
    cleanedDF.unpersist()
    ValidUrlRestaurantDF.persist()
    
    restaurantWithMaxRatingforCuisines(spark, ValidUrlRestaurantDF)          //3rd use case
    distributionOfRatings(spark, ValidUrlRestaurantDF)                       //4th use case
    HighestRatedRestinCostBucket(spark, ValidUrlRestaurantDF, args)          //5th use case
    publishIntoKafkaOnLocation(spark, ValidUrlRestaurantDF)                  //6th use case
  }
  
  
  /****   Remove Non-ascii chars from file *******/
  def removeNonAscii(args:Array[String]) {
    val reader = scala.io.Source.fromFile(args(0))
    val writer = new PrintWriter(new File(args(1) + "/clean1.csv")) 
    for (line <- reader.getLines) {
      val dest = line.replaceAll("[\\P{ASCII}]", "")
      writer.write(dest+EOL);
    }
  }
  
  
  
  /************** data clean up  **********/
  def doDataCleanUp(spark:SparkSession, args:Array[String]): DataFrame = {
    import spark.implicits._
    //take rating drop /5
    val rateChange = (str:String) => {
      str.split("/").head.trim().toDouble
    }
    val rateChangeUDF = udf(rateChange)
    val inputDataDF = spark.read.format("csv")
                           .option("header", "true")
                           .option("inferSchema", "true")
                           .option("multiLine", "true")
                           .option("escape", "\"")
                           .option("delimiter", ",")
                           .load(args(1) + "/clean1.csv")
                           .withColumnRenamed("approx_cost(for two people)", "cost")
                           .withColumnRenamed("listed_in(type)", "listed_in_type")
                           .withColumnRenamed("listed_in(city)", "listed_in_city")
                           .withColumn("phone", regexp_replace(col("phone"),"[\r\n]", "|"))
                           .withColumn("reviews_list", regexp_replace(col("reviews_list"),"\\\\x[0-9]{2}", ""))
                           .withColumn("reviews_list", regexp_replace(col("reviews_list"),"\\\\n", ""))
                           .withColumn("reviews_list", regexp_replace(col("reviews_list"),"[\\?]", ""))
                           .filter(col("rate") rlike "[1-5].[0-9]/5")
                           .withColumn("rate", rateChangeUDF($"rate").cast(DoubleType))
                           .withColumn("votes", col("votes").cast(IntegerType))
                           .withColumn("cost", col("cost").cast(IntegerType));
    //save files
    inputDataDF.write.format("csv")
                .option("header", "true")
                .mode("overwrite")
                .save(args(1) + "/cleanedZomato.csv");
    inputDataDF.write.format("parquet")
                .option("header", "true")
                .mode("overwrite")
                .save(args(1) + "/cleanedZomato.parquet");  
    inputDataDF
  }
  
  
  
  /**
   * 1st use case
   * Filter out records which have invalid restaurant links
   * restaurants that are closed 
   */
  def invalidRestaurants(spark:SparkSession, inputDF:DataFrame, urlExpr:String) = {
    import spark.implicits._
    //using status code udf
    val urlCheck = (str:String) => {
      val url  =  str.split("\\?")(0)
      val r  =  requests.get(url)
      println(r.statusCode)
      if (r.statusCode==0)
        0
      else
        1
    }
    val urlCheckUdf = udf(urlCheck)
    
    val invalidRestaurantsDF = inputDF.select($"url", $"name", $"address", $"location")
                                      .filter(!($"url" rlike urlExpr))
                                     // .withColumn("url", urlCheckUdf(col("url").as("status_code")))
                                     // .filter(col("status_code") === 0);
    //invalidRestaurantsDF.show()
    invalidRestaurantsDF
  }
  
  
  
  /**
   * 2nd use case
   * Group by Address location for the closed restaurants and
   * find out which area has the most restaurants getting closed.
   */
  def locationWithMostClosedRest(inputDF:DataFrame) = {
    val MostClosedRestLoc = inputDF.groupBy("location").count().sort(desc("count")).first()
    println("Most closed resturant are in: " + MostClosedRestLoc) 
    MostClosedRestLoc
  }
  
  
  
  
  
  /**
   * 3rd use case
   * restaurants which are still working, 
   * group by restaurant type and location and 
   * find out the restaurants which have highest rating for each cuisine type.
   */
  def restaurantWithMaxRatingforCuisines(spark:SparkSession, inputDF:DataFrame) = {
    import spark.implicits._
    val restaurantwithMaxRating = inputDF.select($"name", $"rest_type", $"cuisines", $"rate", $"location")
                                 .select(col("*"), split(col("rest_type"),",").as("rest_typeList")).drop("rest_type")
                                 .select(col("*"), explode(col("rest_typeList")).as("rest_type")).drop("rest_typeList")
                                 .select(col("*"), split(col("cuisines"),",").as("cuisinesList")).drop("cuisines")
                                 .select(col("*"), explode(col("cuisinesList")).as("cuisines")).drop("cuisinesList")
                                 .withColumn("max_rating", row_number().over(Window.partitionBy("rest_type", "location", "cuisines").orderBy(col("rate").desc)))
                                 .filter(col("max_rating") === 1)
                                 .drop(col("max_rating"))
                                 .orderBy(col("rest_type"), col("location"), col("cuisines"), col("name"), col("rate").desc);
    //restaurantwithMaxRating.show()
    restaurantwithMaxRating
  }
  
  
  
  
  
  /**
   * 4th use case
   * For the reviews list column, find the distribution of star rating
   */
  def distributionOfRatings(spark:SparkSession, inputDF:DataFrame) = {
    import spark.implicits._
    val pattern = "[1-5]{1}.0".r
    val review = (str:String) => {
      val list = pattern.findAllIn(str).toList
      var result = List[Double]()
      list.map(ele => {
        val finalval = ele.toString().toDouble
        if(finalval <= 5.0 && finalval > 0.0) {
          result :+= finalval
        }
      })
      
      val res = result.groupBy(x => x)  
                     .mapValues(x => x.length)
      res.toString()
    }
    val reviewUDF = udf(review)
    val distributionRatingDF = inputDF.select($"name", $"reviews_list", $"votes")
                                      .filter(col("votes") >= 30)
                                      .withColumn("rating", reviewUDF(col("reviews_list")))
                                      .drop(col("reviews_list"));
    //distributionRatingDF.show(false)
    distributionRatingDF
  }
  
  
  
  /**
   * 5th use case
   * Group by location for individual cost buckets (for 2 people) : [<=300, 300-500, 500-800, >= 800] and
   * take the 5 highest rated restaurants in each location and each cost bucket and save as parquet file
   */
  def HighestRatedRestinCostBucket(spark:SparkSession, inputDF:DataFrame, args:Array[String]) = {
    import spark.implicits._
    val columnWithCostBucketDF = inputDF.select($"location", $"name", $"rate", $"cost")
                                       .withColumn("range", when(col("cost") <= 300, lit("[<=300]"))
                                                .otherwise(when(col("cost") > 300 and col("cost") <= 500 , lit("[300-500]"))
                                                    .otherwise(when(col("cost") > 500 and col("cost") <= 800 , lit("[500-800]"))
                                                          .otherwise(when(col("cost") > 800 , lit("[>800]"))))))
                                       .filter(col("cost") rlike "[0-9]+");
    
    val windowSpec = Window.partitionBy($"location", $"range").orderBy(col("rate").desc)
    val HighestRatedRestDF = columnWithCostBucketDF.groupBy(col("location"), col("range"), col("name"), col("cost"))
                                     .agg(max(col("rate")).as("rate"))
                                     .withColumn("rank", row_number().over(windowSpec))
                                     .orderBy(col("location"), col("range"), col("rate").desc)
                                     .filter(col("rank") <= 5)
                                     .drop(col("rank"));
    
    //HighestRatedRestDF.show()
    HighestRatedRestDF.coalesce(1).write.format("parquet")
                                  .option("header", "true")
                                  .mode("overwrite")
                                  .save(args(1) + "/out5.parquet");
    HighestRatedRestDF
  }
  
  
  
  
  
  
  /**
   * 6th use case
   * restaurants which are not closed, publish the data into individual kafka topics based on location
   */
  def publishIntoKafkaOnLocation(spark:SparkSession, inputDF:DataFrame) {
    import spark.implicits._
    
    val props = new Properties
    props.put("bootstrap.servers", "localhost:9092");
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
    
    val producer: KafkaProducer[String, String] = new KafkaProducer[String, String](props);
    try {
      inputDF.collect().foreach(data => {
        val topicAsLocation = data.getAs("location").toString().trim().replaceAll(" ", "_")
        val record: ProducerRecord[String, String] = new ProducerRecord[String, String](topicAsLocation, data.toString());
        producer.send(record);
      })
    } catch {
      case ex: Exception => println(ex)
    }
    
    //using kafka format
//    val kafkaDF = zomatoDF.select(col("location"),
//                            to_json(struct(col("name"), col("rest_type"),col("cuisines"),col("reviews_list"),col("rate"))).alias("value"))
//                          .selectExpr("location", "CAST(null AS STRING)", "CAST(value AS STRING)")
//                          .write
//                          .format("kafka")
//                          .option("kafka.bootstrap.servers", "localhost:9092")
//                          //.option("topic", $"location".toString().trim())
//                          .save()
    
  }
  
}