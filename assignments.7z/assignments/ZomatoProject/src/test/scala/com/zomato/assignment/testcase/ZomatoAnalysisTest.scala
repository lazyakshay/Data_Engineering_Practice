package com.zomato.assignment.testcase

import org.scalatest.FunSuite
import com.zomato.assignment.ZomatoAnalysis
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import java.io.File
import java.nio.file._
import org.scalatest.BeforeAndAfterAll
import java.nio.file.attribute.BasicFileAttributes


class ZomatoAnalysisTest extends FunSuite with BeforeAndAfterAll {
  
  System.setProperty("hadoop.home.dir", "D:/hadoop/");
  
  //var spark : SparkSession = _
  val spark = SparkSession
          .builder()
          .appName("Akshay Zomato Analysis Test")
          .master("local")
          .getOrCreate()
          
//  override protected def beforeAll(): Unit = {
//    spark = SparkSession
//          .builder()
//          .appName("Akshay Zomato Analysis Test")
//          .master("local")
//          .getOrCreate()
//    spark.sparkContext.setLogLevel("INFO")
//  }
  
          
  val urlExpr = "http[s]://www.zomato.com/(bangalore/|SanchurroBangalore)" +
                    "[a-zA-Z0-9@:%._\\+\\-~#?&//=]{0,256}" + "?context=.*";
  
  ///hadoop/project/input/ /hadoop/project/output/
  val args = Array("D:/hadoop/project/input/zomato.csv", "D:/hadoop/project/output/")
  
  val inputDF = spark.read.format("parquet")
                              .option("header", "true")
                              .option("inferSchema", "true")
                              .load(args(1) + "/cleanedZomato.parquet");
  
  val invalidUrlRestDF = inputDF.filter(!(col("url") rlike urlExpr))
  val validUrlRestDF = inputDF.filter(col("url") rlike urlExpr).drop(col("url"))
  
  
  
  
  //test cases starts
  test("TestCase1: Find invalid restaurants") {
    val invalidDF = ZomatoAnalysis.invalidRestaurants(spark, inputDF, urlExpr)
    val checkURL = invalidDF.first().get(0).toString()
    assert(!checkURL.matches(urlExpr))
  }
  
  
   test("TestCase2: Location in which most restaurant closed"){
     val firstDF = ZomatoAnalysis.locationWithMostClosedRest(invalidUrlRestDF)
     assert(firstDF.get(0).equals("South Bangalore"))
   }
   
   test("TestCase3: Higest Rated Restaurant for each cuisines"){
     val testDF = ZomatoAnalysis.restaurantWithMaxRatingforCuisines(spark, validUrlRestDF)
     assert(testDF.count() == 8690)
   }
   
   test("TestCase4: Distribution of star ratings"){
     val testDF = ZomatoAnalysis.distributionOfRatings(spark, validUrlRestDF)
     assert(testDF.count() == 14439)
   }
   
   test("TestCase5: HigestRated Restaurant in each cost bucket"){
     val testDF = ZomatoAnalysis.HighestRatedRestinCostBucket(spark, validUrlRestDF, args)
     assert(testDF.count() == 987)
   }
   
//   test("TestCase6: publish data into kafka based on location as topic"){
//     ZomatoAnalysis.publishIntoKafkaOnLocation(spark, validUrlRestDF)
//   }
  
  //test cases ends
}